//#region node_modules/.nitro/vite/services/ssr/assets/db-CNQMjRIS.js
var _0002_cinema_default = "-- Nexora Dolby Cinema. PostgreSQL schema shared by preview and deploy.\n\ncreate table if not exists halls (\n  id text primary key,\n  name text not null,\n  tagline text not null,\n  projection text not null,\n  sound text not null,\n  supports_3d boolean not null,\n  capacity integer not null,\n  price_2d integer not null,\n  price_3d integer\n);\n\ncreate table if not exists seats (\n  id serial primary key,\n  hall_id text not null references halls(id),\n  row_label text not null,\n  seat_number integer not null,\n  seat_code text not null,\n  unique (hall_id, seat_code)\n);\n\ncreate table if not exists movies (\n  id serial primary key,\n  title text not null,\n  genre text not null,\n  duration_min integer not null,\n  description text not null,\n  poster_url text not null,\n  trailer_url text not null,\n  format text not null check (format in ('2D', '3D')),\n  release_date date not null,\n  status text not null check (status in ('Now Showing', 'Coming Soon'))\n);\n\ncreate table if not exists showtimes (\n  id serial primary key,\n  movie_id integer not null references movies(id) on delete cascade,\n  hall_id text not null references halls(id),\n  show_date date not null,\n  start_time text not null,\n  format text not null check (format in ('2D', '3D')),\n  ticket_price integer not null,\n  unique (hall_id, show_date, start_time)\n);\n\ncreate table if not exists customers (\n  id serial primary key,\n  full_name text not null,\n  phone text not null,\n  email text not null\n);\n\ncreate table if not exists bookings (\n  id serial primary key,\n  customer_id integer not null references customers(id),\n  showtime_id integer not null references showtimes(id),\n  booked_at timestamptz not null default now(),\n  total_amount integer not null,\n  payment_status text not null,\n  booking_status text not null,\n  ticket_code text not null unique,\n  seat_list text not null\n);\n\ncreate table if not exists booking_seats (\n  id serial primary key,\n  booking_id integer not null references bookings(id) on delete cascade,\n  seat_id integer not null references seats(id),\n  showtime_id integer not null references showtimes(id),\n  unique (showtime_id, seat_id)\n);\n\ncreate table if not exists payments (\n  id serial primary key,\n  booking_id integer not null references bookings(id),\n  amount integer not null,\n  payment_method text not null,\n  payment_status text not null,\n  transaction_reference text not null,\n  payment_date timestamptz not null default now()\n);\n\ncreate index if not exists showtimes_movie_idx on showtimes (movie_id, show_date);\ncreate index if not exists bookings_showtime_idx on bookings (showtime_id);\n\ninsert into halls (id, name, tagline, projection, sound, supports_3d, capacity, price_2d, price_3d)\nvalues\n  ('C1', 'NEXORA Dolby Cinema', 'The flagship house', '8K Laser', 'Dolby Atmos', true, 140, 1500, 1800),\n  ('C2', 'House Two', 'A sharp, close room', '2K Projector', '7.1 Surround', true, 140, 1300, 1500),\n  ('C3', 'House Three', '2D only, by design', '2K Projector', '7.1 Surround', false, 140, 1300, null)\non conflict (id) do nothing;\n\ninsert into seats (hall_id, row_label, seat_number, seat_code)\nselect h.id, chr(64 + r.n), s.n, chr(64 + r.n) || s.n::text\nfrom halls h\ncross join generate_series(1, 7) as r(n)\ncross join generate_series(1, 20) as s(n)\nwhere not exists (select 1 from seats limit 1);\n\ninsert into movies (title, genre, duration_min, description, poster_url, trailer_url, format, release_date, status)\nselect * from (values\n  ('Eclipse Meridian', 'Sci-Fi', 169,\n   'A survey ship stalls on the lip of a star that should not exist. The crew has one orbit to decide what they are willing to forget.',\n   '/films/eclipse-meridian.jpg', 'https://www.youtube.com/watch?v=R6MlUcmOul8', '3D', current_date - 24, 'Now Showing'),\n  ('Glass Tide', 'Adventure', 148,\n   'When the southern sea turns to black glass, a navigator sails toward a light that keeps moving just under the surface.',\n   '/films/glass-tide.jpg', 'https://www.youtube.com/watch?v=Y-rmzh0PI3c', '2D', current_date - 40, 'Now Showing'),\n  ('Velvet Static', 'Thriller', 118,\n   'A night editor uncovers a broadcast that plays only for people who are about to disappear.',\n   '/films/velvet-static.jpg', 'https://www.youtube.com/watch?v=TLkA0RELQ1g', '2D', current_date - 12, 'Now Showing'),\n  ('Crown of Ash', 'Fantasy', 156,\n   'The last coronation in a burned kingdom is performed for an empty throne, and the crown still answers.',\n   '/films/crown-of-ash.jpg', 'https://www.youtube.com/watch?v=eRsGyueVLvQ', '3D', current_date - 18, 'Now Showing'),\n  ('Paper Moons', 'Romance', 112,\n   'Two strangers trade paper boats across a night harbor, each one carrying a promise they are not ready to say aloud.',\n   '/films/paper-moons.jpg', 'https://www.youtube.com/watch?v=WhWc3b3KhnY', '2D', current_date - 9, 'Now Showing'),\n  ('Orchard Voltage', 'Animation', 102,\n   'In a grove that fruits only after midnight, a cartographer maps fruit that remembers every hand that picked it.',\n   '/films/orchard-voltage.jpg', 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', '2D', current_date - 30, 'Now Showing'),\n  ('Hollow Frequency', 'Horror', 128,\n   'A closed concert hall keeps selling one seat. Whoever sits there hears the encore that never happened.',\n   '/films/hollow-frequency.jpg', 'https://www.youtube.com/watch?v=R6MlUcmOul8', '3D', current_date + 21, 'Coming Soon'),\n  ('Meridian Fall', 'Drama', 141,\n   'On the last calm evening before a city changes its name, a daughter walks the cliff road her mother mapped by hand.',\n   '/films/meridian-fall.jpg', 'https://www.youtube.com/watch?v=WhWc3b3KhnY', '2D', current_date + 35, 'Coming Soon')\n) as v(title, genre, duration_min, description, poster_url, trailer_url, format, release_date, status)\nwhere not exists (select 1 from movies limit 1);\n\n-- C1: 10:00 Glass Tide, 13:00 Eclipse Meridian, 16:30 Velvet Static, 19:00 Paper Moons\ninsert into showtimes (movie_id, hall_id, show_date, start_time, format, ticket_price)\nselect m.id, 'C1', current_date + d.n, t.start_time, m.format, t.price\nfrom generate_series(0, 4) as d(n)\njoin (values\n  ('Glass Tide', '10:00', 1500),\n  ('Eclipse Meridian', '13:00', 1800),\n  ('Velvet Static', '16:30', 1500),\n  ('Paper Moons', '19:00', 1500)\n) as t(title, start_time, price) on true\njoin movies m on m.title = t.title\nwhere not exists (select 1 from showtimes limit 1);\n\ninsert into showtimes (movie_id, hall_id, show_date, start_time, format, ticket_price)\nselect m.id, 'C2', current_date + d.n, t.start_time, m.format, t.price\nfrom generate_series(0, 4) as d(n)\njoin (values\n  ('Crown of Ash', '11:00', 1500),\n  ('Orchard Voltage', '14:15', 1300),\n  ('Glass Tide', '16:30', 1300),\n  ('Eclipse Meridian', '19:30', 1500)\n) as t(title, start_time, price) on true\njoin movies m on m.title = t.title\nwhere (select count(*) from showtimes) = 20;\n\ninsert into showtimes (movie_id, hall_id, show_date, start_time, format, ticket_price)\nselect m.id, 'C3', current_date + d.n, t.start_time, m.format, t.price\nfrom generate_series(0, 4) as d(n)\njoin (values\n  ('Velvet Static', '10:30', 1300),\n  ('Paper Moons', '13:00', 1300),\n  ('Orchard Voltage', '15:30', 1300),\n  ('Glass Tide', '18:00', 1300)\n) as t(title, start_time, price) on true\njoin movies m on m.title = t.title\nwhere (select count(*) from showtimes) = 40;\n\ninsert into customers (full_name, phone, email)\nselect * from (values\n  ('Amaya Fernando', '0775550142', 'amaya.fernando@example.com'),\n  ('Rohan Silva', '0715550188', 'rohan.silva@example.com'),\n  ('Nila Perera', '0765550130', 'nila.perera@example.com')\n) as v(full_name, phone, email)\nwhere not exists (select 1 from customers limit 1);\n\ninsert into bookings (customer_id, showtime_id, total_amount, payment_status, booking_status, ticket_code, seat_list)\nselect c.id, s.id, 3000, 'Paid', 'Confirmed',\n  'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100001', 'C4, C5'\nfrom customers c\njoin showtimes s on s.hall_id = 'C1' and s.start_time = '10:00' and s.show_date = current_date\njoin movies m on m.id = s.movie_id and m.title = 'Glass Tide'\nwhere c.email = 'amaya.fernando@example.com'\n  and not exists (select 1 from bookings limit 1);\n\ninsert into booking_seats (booking_id, seat_id, showtime_id)\nselect b.id, st.id, b.showtime_id\nfrom bookings b\njoin seats st on st.hall_id = 'C1' and st.seat_code in ('C4', 'C5')\nwhere b.ticket_code = 'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100001';\n\ninsert into bookings (customer_id, showtime_id, total_amount, payment_status, booking_status, ticket_code, seat_list)\nselect c.id, s.id, 1500, 'Paid', 'Confirmed',\n  'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100002', 'A1'\nfrom customers c\njoin showtimes s on s.hall_id = 'C2' and s.start_time = '11:00' and s.show_date = current_date\njoin movies m on m.id = s.movie_id and m.title = 'Crown of Ash'\nwhere c.email = 'rohan.silva@example.com'\n  and not exists (select 1 from bookings where ticket_code like '%-100002');\n\ninsert into booking_seats (booking_id, seat_id, showtime_id)\nselect b.id, st.id, b.showtime_id\nfrom bookings b\njoin seats st on st.hall_id = 'C2' and st.seat_code = 'A1'\nwhere b.ticket_code = 'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100002';\n\ninsert into bookings (customer_id, showtime_id, total_amount, payment_status, booking_status, ticket_code, seat_list)\nselect c.id, s.id, 2600, 'Paid', 'Confirmed',\n  'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100003', 'B10, B11'\nfrom customers c\njoin showtimes s on s.hall_id = 'C3' and s.start_time = '13:00' and s.show_date = current_date\njoin movies m on m.id = s.movie_id and m.title = 'Paper Moons'\nwhere c.email = 'nila.perera@example.com'\n  and not exists (select 1 from bookings where ticket_code like '%-100003');\n\ninsert into booking_seats (booking_id, seat_id, showtime_id)\nselect b.id, st.id, b.showtime_id\nfrom bookings b\njoin seats st on st.hall_id = 'C3' and st.seat_code in ('B10', 'B11')\nwhere b.ticket_code = 'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100003';\n\ninsert into payments (booking_id, amount, payment_method, payment_status, transaction_reference)\nselect b.id, b.total_amount, 'Card', 'Paid', 'TXN-' || b.id::text\nfrom bookings b\nwhere not exists (select 1 from payments limit 1);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_cinema.sql": _0002_cinema_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
//#endregion
export { getSql };
