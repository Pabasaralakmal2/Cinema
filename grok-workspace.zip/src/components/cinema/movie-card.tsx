import { Link } from "@tanstack/react-router";
import { formatDuration } from "@/lib/cinema/rules";
import type { Movie } from "@/lib/cinema/types";

export function MovieCard({ movie }: { movie: Movie }) {
  const soon = movie.status === "Coming Soon";
  return (
    <Link
      to="/movies/$movieId"
      params={{ movieId: String(movie.id) }}
      className="group block"
    >
      <article className="overflow-hidden rounded-2xl border border-line bg-surface">
        <div className="relative aspect-[2/3] overflow-hidden">
          <img
            src={movie.poster_url}
            alt=""
            className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-[1.03]"
          />
          <div className="absolute inset-x-0 bottom-0 bg-bg/80 p-3">
            <p className="font-display text-2xl leading-none text-cream">{movie.title}</p>
            <p className="mt-2 text-xs tracking-wide text-muted">
              {movie.genre} · {formatDuration(movie.duration_min)} · {movie.format}
            </p>
          </div>
        </div>
        <p className="px-3 py-3 text-sm text-gold">{soon ? "Coming soon" : "Book a seat"}</p>
      </article>
    </Link>
  );
}
