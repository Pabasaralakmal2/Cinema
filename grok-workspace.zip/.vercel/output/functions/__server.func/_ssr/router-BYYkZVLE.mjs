import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as array, o as string, r as literal, s as union, t as _enum } from "../_libs/zod.mjs";
import { t as Pending } from "./shell-C7TEGcdy.mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-wjhTouIh.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var CinemaError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "CinemaError";
	}
};
function parse(schema, input) {
	const res = schema.safeParse(input);
	if (!res.success) throw new CinemaError(res.error.issues[0]?.message ?? "Check the form and try again.");
	return res.data;
}
var movieSchema = object({
	id: number().int().positive().optional(),
	title: string().trim().min(1, "Give the film a title.").max(120),
	genre: string().trim().min(2, "Add a genre.").max(40),
	durationMin: number().int().min(45, "Runtime looks too short.").max(300, "Runtime looks too long."),
	description: string().trim().min(10, "Add a short description.").max(800),
	posterUrl: string().trim().min(1, "Add a poster address.").max(400),
	trailerUrl: string().trim().url("Trailer needs a full web address.").max(400),
	format: _enum(["2D", "3D"]),
	releaseDate: string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use a real release date."),
	status: _enum(["Now Showing", "Coming Soon"])
});
var showSchema = object({
	id: number().int().positive().optional(),
	movieId: number().int().positive(),
	hallId: string().trim().min(1),
	showDate: string().regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a date."),
	startTime: string().regex(/^([01]\d|2[0-3]):[0-5]\d/, "Choose a start time.")
});
var personSchema = object({
	fullName: string().trim().min(2, "Enter the name on the ticket.").max(80),
	phone: string().trim().refine((value) => value.replace(/\D/g, "").length >= 9 && value.replace(/\D/g, "").length <= 15, { message: "Enter a phone number we can read back." }),
	email: string().trim().email("Enter a valid email.").max(120)
});
var getHome = createServerFn({ method: "GET" }).handler(createSsrRpc("8fa606defa0a5ff4be69b37a17276f3d746c53a9a4544613844ec0b2a35ff353"));
var getMovie = createServerFn({ method: "GET" }).validator((input) => parse(object({ id: number().int().positive() }), input)).handler(createSsrRpc("f3e67719a4b3072f3dbaeb98c9ada7c2e6ec668538c1b769aed44ce2cd77e66b"));
var getShowtime = createServerFn({ method: "GET" }).validator((input) => parse(object({ id: number().int().positive() }), input)).handler(createSsrRpc("6ae68061f5ed49dea0e3c79dc369f865823e4c1b0ff7f5b8433a63c811ad10af"));
var bookSchema = personSchema.extend({
	showtimeId: number().int().positive(),
	seatIds: array(number().int().positive()).min(1, "Choose at least one seat.").max(10, "Ten seats is the house limit.")
});
var createBooking = createServerFn({ method: "POST" }).validator((input) => parse(bookSchema, input)).handler(createSsrRpc("33210d0c3e4b68a72c8b1b002cc33609535f4f57cdf50cf56cfeeefc8aa0ca25"));
var getTicket = createServerFn({ method: "GET" }).validator((input) => parse(object({ code: string().trim().min(4).max(40) }), input)).handler(createSsrRpc("3718de972080aac40311675977e7199534f3b91706ec3844a6486b59409f5228"));
var houseSchema = object({ code: string().min(1, "Enter the house code.") });
var staffDesk = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema, input)).handler(createSsrRpc("09eb8761f5cfe1fe797c0167b179a303003ced8e7359a6d04c37b2dd05189937"));
var saveMovie = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ movie: movieSchema }), input)).handler(createSsrRpc("b7fdbac884d8fdf0c8b6a925bf93ec1fde6f89987d9f49fe6c24d8bd6efb1bc5"));
var deleteMovie = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ id: number().int().positive() }), input)).handler(createSsrRpc("a4a91ffcd5e7eab9c452a5359a8caadb883136c4cbcf35affb249c37a9c3502c"));
var saveShowtime = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ show: showSchema }), input)).handler(createSsrRpc("7f598179fc3466f3d21d050f208c97ec91d33541349663e7b75726be7991d105"));
var deleteShowtime = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ id: number().int().positive() }), input)).handler(createSsrRpc("c43b15a9e0326f63a83b9927dc13a10f984620e9b71cdb0e3d4d2a534d034276"));
var updateCustomer = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({
	id: number().int().positive(),
	person: personSchema
}), input)).handler(createSsrRpc("df45e0156a38bcb835bda4853bf7933ca17796830fbbed978bf5676ce7b33191"));
var deleteCustomer = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ id: number().int().positive() }), input)).handler(createSsrRpc("091f7a39564dec35e4012b0512979f9b49c7c486ca79b8aa25984bdab6e5d397"));
var setBookingStatus = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({
	id: number().int().positive(),
	status: _enum(["Cancelled", "Used"])
}), input)).handler(createSsrRpc("2cc35c237ddf0fcae2516f8da3d65e67961c63fafda357e83ce07e27b89aeab9"));
var verifyTicket = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ ticketCode: string().trim().min(4).max(40) }), input)).handler(createSsrRpc("5a1a726b85e11498dbd69a499be77a683eb231664e5191a1914991de4b6a5dd9"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-BYYkZVLE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
				className: "size-10 text-alert",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-4catxSKa.css";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Nexora Dolby Cinema" },
			{
				name: "description",
				content: "Nexora Dolby Cinema. Where stories become worlds."
			},
			{
				name: "theme-color",
				content: "#0c0b0a"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,500&family=Outfit:wght@300;400;500;600&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$6 = () => import("./routes-Dl9Jm7WW.mjs");
var Route$6 = createFileRoute("/")({
	loader: () => getHome(),
	pendingComponent: Pending,
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./contact-BFT9aH-U.mjs");
var Route$5 = createFileRoute("/contact")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./staff-T7Pv3mvG.mjs");
var Route$4 = createFileRoute("/staff")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./tickets-D-RZyg_f.mjs");
var Route$3 = createFileRoute("/tickets")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./book._showtimeId-CjnPPSFP.mjs");
var Route$2 = createFileRoute("/book/$showtimeId")({
	loader: ({ params }) => getShowtime({ data: { id: Number(params.showtimeId) } }),
	pendingComponent: Pending,
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./movies._movieId-CkEAx4Ew.mjs");
var Route$1 = createFileRoute("/movies/$movieId")({
	loader: ({ params }) => getMovie({ data: { id: Number(params.movieId) } }),
	pendingComponent: Pending,
	head: ({ loaderData }) => ({ meta: [{ title: loaderData?.movie ? `${loaderData.movie.title} — Nexora` : "Film — Nexora" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./ticket._code-0UVHBS9W.mjs");
var Route = createFileRoute("/ticket/$code")({
	loader: ({ params }) => getTicket({ data: { code: params.code } }),
	pendingComponent: Pending,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	ContactRoute: Route$5.update({
		id: "/contact",
		path: "/contact",
		getParentRoute: () => Route$7
	}),
	StaffRoute: Route$4.update({
		id: "/staff",
		path: "/staff",
		getParentRoute: () => Route$7
	}),
	TicketsRoute: Route$3.update({
		id: "/tickets",
		path: "/tickets",
		getParentRoute: () => Route$7
	}),
	BookShowtimeIdRoute: Route$2.update({
		id: "/book/$showtimeId",
		path: "/book/$showtimeId",
		getParentRoute: () => Route$7
	}),
	MoviesMovieIdRoute: Route$1.update({
		id: "/movies/$movieId",
		path: "/movies/$movieId",
		getParentRoute: () => Route$7
	}),
	TicketCodeRoute: Route.update({
		id: "/ticket/$code",
		path: "/ticket/$code",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$6 as a, deleteMovie as c, saveShowtime as d, setBookingStatus as f, verifyTicket as h, Route$2 as i, deleteShowtime as l, updateCustomer as m, Route as n, createBooking as o, staffDesk as p, Route$1 as r, deleteCustomer as s, router_exports as t, saveMovie as u };
