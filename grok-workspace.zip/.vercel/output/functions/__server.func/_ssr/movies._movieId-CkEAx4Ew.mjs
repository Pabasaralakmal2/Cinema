import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as formatDuration, d as youtubeId, i as formatDay, o as formatLkr, r as formatClock } from "./rules-COHaUayQ.mjs";
import { n as Shell } from "./shell-C7TEGcdy.mjs";
import { r as Route$1 } from "./router-BYYkZVLE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/movies._movieId-CkEAx4Ew.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MoviePage() {
	const data = Route$1.useLoaderData();
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-6 py-24 text-muted",
		children: "That film is not on the programme."
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MovieBody, { data });
}
function MovieBody({ data }) {
	const { movie, showtimes } = data;
	const dates = (0, import_react.useMemo)(() => [...new Set(showtimes.map((show) => show.show_date))], [showtimes]);
	const [date, setDate] = (0, import_react.useState)(dates[0] ?? "");
	const dayShows = showtimes.filter((show) => show.show_date === date);
	const trailer = youtubeId(movie.trailer_url);
	const soon = movie.status === "Coming Soon";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[280px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: movie.poster_url,
			alt: "",
			className: "w-full rounded-2xl border border-line object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-gold",
				children: movie.status.toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-6xl leading-none",
				children: movie.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-muted",
				children: [
					movie.genre,
					" · ",
					formatDuration(movie.duration_min),
					" · ",
					movie.format,
					soon ? ` · Opens ${formatDay(movie.release_date)}` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-2xl text-lg",
				children: movie.description
			}),
			movie.format === "3D" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-gold",
				children: "3D plays in C1 and C2 only. C3 stays dark for this format."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 overflow-hidden rounded-2xl border border-line bg-black",
				children: trailer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					className: "aspect-video w-full",
					src: `https://www.youtube-nocookie.com/embed/${trailer}`,
					title: `${movie.title} trailer`,
					allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
					allowFullScreen: true
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-muted",
					children: "The trailer link is not a YouTube address yet."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted",
				children: "House preview reel. Staff can replace the link."
			})
		] })]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-4 pb-8 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-4xl",
			children: soon ? "Not open yet" : "Choose a screening"
		}), soon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-xl text-muted",
			children: "Coming soon titles stay off the booking board until staff marks them Now Showing."
		}) : dates.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-muted",
			children: "No screenings are on the board for the days ahead."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 flex gap-2 overflow-x-auto pb-2",
			children: dates.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setDate(item),
				className: `min-h-11 shrink-0 rounded-full px-4 ${item === date ? "bg-gold text-bg" : "border border-line text-cream"}`,
				children: formatDay(item)
			}, item))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-3",
			children: dayShows.map((show) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/book/$showtimeId",
				params: { showtimeId: String(show.id) },
				className: "grid gap-2 rounded-2xl border border-line bg-surface p-4 sm:grid-cols-[7rem_1fr_auto] sm:items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl tabular-nums",
						children: formatClock(show.start_time)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-cream",
						children: [
							show.hall_id,
							" · ",
							show.hall_name
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							show.projection,
							" · ",
							show.sound,
							" · ",
							show.format
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-gold tabular-nums",
						children: formatLkr(show.ticket_price)
					})
				]
			}, show.id))
		})] })]
	})] });
}
//#endregion
export { MoviePage as component };
