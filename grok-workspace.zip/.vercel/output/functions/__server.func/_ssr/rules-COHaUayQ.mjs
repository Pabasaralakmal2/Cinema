//#region node_modules/.nitro/vite/services/ssr/assets/rules-COHaUayQ.js
var GENRES = [
	"Action",
	"Adventure",
	"Drama",
	"Comedy",
	"Horror",
	"Sci-Fi",
	"Thriller",
	"Romance",
	"Animation",
	"Fantasy"
];
function formatDuration(mins) {
	const h = Math.floor(mins / 60);
	const m = mins % 60;
	if (h <= 0) return `${m}m`;
	if (m === 0) return `${h}h`;
	return `${h}h ${m}m`;
}
function formatLkr(amount) {
	return `LKR ${amount.toLocaleString("en-US")}`;
}
function formatClock(hhmm) {
	const [hStr, mStr] = hhmm.slice(0, 5).split(":");
	let h = Number(hStr);
	const m = mStr ?? "00";
	const ap = h >= 12 ? "PM" : "AM";
	h = h % 12;
	if (h === 0) h = 12;
	return `${h}:${m} ${ap}`;
}
function formatDay(iso) {
	const [y, mo, d] = iso.slice(0, 10).split("-").map(Number);
	return new Date(Date.UTC(y, (mo || 1) - 1, d || 1)).toLocaleDateString("en-GB", {
		weekday: "short",
		day: "numeric",
		month: "short",
		timeZone: "UTC"
	});
}
function clockToMinutes(hhmm) {
	const [h, m] = hhmm.slice(0, 5).split(":").map(Number);
	return (h || 0) * 60 + (m || 0);
}
/** Two screenings overlap when one starts before the other has ended, plus a 20-minute turn. */
function rangesOverlap(startA, durA, startB, durB, gap = 20) {
	return startA < startB + durB + gap && startB < startA + durA + gap;
}
/**
* House prices. C3 has no 3D lamp, so that combination has no price.
* C1 2D 1500, C1 3D 1800, C2 2D 1300, C2 3D 1500, C3 2D 1300.
*/
function priceFor(hallId, format) {
	if (hallId === "C1" && format === "2D") return 1500;
	if (hallId === "C1" && format === "3D") return 1800;
	if (hallId === "C2" && format === "2D") return 1300;
	if (hallId === "C2" && format === "3D") return 1500;
	if (hallId === "C3" && format === "2D") return 1300;
	return null;
}
function youtubeId(url) {
	try {
		const u = new URL(url.trim());
		if (u.hostname.includes("youtu.be")) {
			const id = u.pathname.split("/").filter(Boolean)[0] ?? "";
			return id.length >= 11 ? id.slice(0, 11) : null;
		}
		const v = u.searchParams.get("v");
		if (v && v.length >= 11) return v.slice(0, 11);
		const parts = u.pathname.split("/");
		const embed = parts.indexOf("embed");
		if (embed >= 0 && parts[embed + 1] && parts[embed + 1].length >= 11) return parts[embed + 1].slice(0, 11);
	} catch {
		return null;
	}
	return null;
}
function luhn(num) {
	let sum = 0;
	let alt = false;
	for (let i = num.length - 1; i >= 0; i -= 1) {
		let n = Number(num[i]);
		if (Number.isNaN(n)) return false;
		if (alt) {
			n *= 2;
			if (n > 9) n -= 9;
		}
		sum += n;
		alt = !alt;
	}
	return sum % 10 === 0;
}
function sortSeatCodes(codes) {
	return [...codes].sort((a, b) => {
		const ra = a.charAt(0);
		const rb = b.charAt(0);
		if (ra !== rb) return ra.charCodeAt(0) - rb.charCodeAt(0);
		return Number(a.slice(1)) - Number(b.slice(1));
	});
}
//#endregion
export { formatDuration as a, priceFor as c, youtubeId as d, formatDay as i, rangesOverlap as l, clockToMinutes as n, formatLkr as o, formatClock as r, luhn as s, GENRES as t, sortSeatCodes as u };
