import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Pending, Shell } from "@/components/cinema/shell";
import { Field, GhostButton, GoldButton, Note, TextInput } from "@/components/cinema/ui";
import { createBooking, getShowtime } from "@/lib/cinema/api";
import { formatClock, formatDay, formatLkr, luhn, sortSeatCodes } from "@/lib/cinema/rules";
import type { Seat } from "@/lib/cinema/types";

export const Route = createFileRoute("/book/$showtimeId")({
  loader: ({ params }) => getShowtime({ data: { id: Number(params.showtimeId) } }),
  pendingComponent: Pending,
  component: BookPage,
});

type Step = "seats" | "details" | "pay";

function BookPage() {
  const data = Route.useLoaderData();
  const seats = data?.seats ?? [];
  const rows = useMemo(() => {
    const grouped = new Map<string, Seat[]>();
    for (const seat of seats) {
      const list = grouped.get(seat.row_label) ?? [];
      list.push(seat);
      grouped.set(seat.row_label, list);
    }
    return [...grouped.entries()];
  }, [seats]);
  const router = useRouter();
  const navigate = Route.useNavigate();
  const [step, setStep] = useState<Step>("seats");
  const [picked, setPicked] = useState<number[]>([]);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [card, setCard] = useState("");
  const [holder, setHolder] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (!data) {
    return (
      <Shell>
        <p className="px-6 py-24 text-muted">That screening has left the board.</p>
      </Shell>
    );
  }

  const { movie, showtime } = data;
  const selected = seats.filter((seat) => picked.includes(seat.id) && seat.status === "available");
  const total = selected.length * showtime.ticket_price;

  function toggle(seat: Seat) {
    if (seat.status === "booked") return;
    if (!picked.includes(seat.id) && picked.length >= 10) {
      setError("Ten seats is the house limit for one ticket.");
      return;
    }
    setError("");
    setPicked((current) =>
      current.includes(seat.id) ? current.filter((id) => id !== seat.id) : [...current, seat.id],
    );
  }

  function validateGuest() {
    if (name.trim().length < 2) return "Enter the name on the ticket.";
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 9 || digits.length > 15) return "Enter a phone number we can read back.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return "Enter a valid email.";
    return "";
  }

  function validateCard() {
    const digits = card.replace(/\D/g, "");
    if (digits.length < 13 || digits.length > 19 || !luhn(digits)) return "That card number does not check out.";
    if (holder.trim().length < 2) return "Enter the name on the card.";
    const match = expiry.trim().match(/^(\d{2})\s*\/\s*(\d{2})$/);
    if (!match) return "Use an expiry like 12/28.";
    const month = Number(match[1]);
    const year = 2000 + Number(match[2]);
    if (month < 1 || month > 12) return "That expiry month is not real.";
    const now = new Date();
    const expired = year < now.getFullYear() || (year === now.getFullYear() && month < now.getMonth() + 1);
    if (expired) return "That card is already expired.";
    if (!/^\d{3,4}$/.test(cvv.trim())) return "Enter the CVV. It is not stored.";
    return "";
  }

  async function pay() {
    const problem = validateCard();
    if (problem) {
      setError(problem);
      return;
    }
    setBusy(true);
    setError("");
    try {
      const result = await createBooking({
        data: {
          showtimeId: showtime.id,
          seatIds: selected.map((seat) => seat.id),
          fullName: name.trim(),
          phone: phone.trim(),
          email: email.trim(),
        },
      });
      await navigate({ to: "/ticket/$code", params: { code: result.ticketCode } });
    } catch (err) {
      setError(err instanceof Error ? err.message : "The booking did not go through.");
      await router.invalidate();
      setPicked([]);
      setStep("seats");
    } finally {
      setBusy(false);
    }
  }

  const codes = sortSeatCodes(selected.map((seat) => seat.seat_code));

  return (
    <Shell>
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[1fr_20rem]">
        <section>
          <p className="text-xs tracking-widest text-gold">{showtime.hall_id} · {showtime.format}</p>
          <h1 className="mt-2 font-display text-5xl">{movie.title}</h1>
          <p className="mt-2 text-muted">
            {formatDay(showtime.show_date)} · {formatClock(showtime.start_time)} · {showtime.hall_name}
          </p>
          <p className="text-sm text-muted">{showtime.projection} · {showtime.sound}</p>

          {step === "seats" ? (
            <div className="mt-8">
              <div className="mb-4 rounded-full border border-line py-2 text-center text-xs tracking-widest text-gold">SCREEN</div>
              <div className="overflow-x-auto pb-3">
                <div className="min-w-max space-y-2">
                  {rows.map(([label, row]) => (
                    <div key={label} className="flex items-center gap-2">
                      <span className="w-5 text-sm text-muted">{label}</span>
                      <div className="flex gap-1">
                        {row.map((seat, index) => {
                          const on = selected.some((item) => item.id === seat.id);
                          const booked = seat.status === "booked";
                          return (
                            <button
                              key={seat.id}
                              type="button"
                              disabled={booked}
                              aria-pressed={on}
                              aria-label={`Seat ${seat.seat_code}, ${booked ? "booked" : on ? "selected" : "available"}`}
                              onClick={() => toggle(seat)}
                              className={`size-11 rounded-sm text-xs tabular-nums ${
                                booked ? "bg-alert text-cream" : on ? "bg-cream text-bg" : "bg-open text-cream"
                              } ${index === 9 ? "ml-4" : ""}`}
                            >
                              {seat.seat_number}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-4 text-sm">
                <span className="inline-flex items-center gap-2"><i className="size-3 rounded-sm bg-open" /> Open</span>
                <span className="inline-flex items-center gap-2"><i className="size-3 rounded-sm bg-alert" /> Booked</span>
                <span className="inline-flex items-center gap-2"><i className="size-3 rounded-sm bg-cream" /> Selected</span>
              </div>
            </div>
          ) : null}

          {step === "details" ? (
            <form
              className="mt-8 grid max-w-md gap-4"
              onSubmit={(event) => {
                event.preventDefault();
                const problem = validateGuest();
                if (problem) setError(problem);
                else {
                  setError("");
                  setStep("pay");
                }
              }}
            >
              <Field label="Full name"><TextInput value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" /></Field>
              <Field label="Phone"><TextInput value={phone} onChange={(event) => setPhone(event.target.value)} autoComplete="tel" inputMode="tel" /></Field>
              <Field label="Email"><TextInput value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" inputMode="email" /></Field>
              <div className="flex gap-3">
                <GhostButton type="button" onClick={() => setStep("seats")}>Back</GhostButton>
                <GoldButton type="submit">Continue</GoldButton>
              </div>
            </form>
          ) : null}

          {step === "pay" ? (
            <form
              className="mt-8 grid max-w-md gap-4"
              onSubmit={(event) => {
                event.preventDefault();
                void pay();
              }}
            >
              <div className="rounded-2xl border border-line bg-surface-2 p-5">
                <p className="text-xs tracking-widest text-gold">CARD</p>
                <p className="mt-6 font-display text-3xl tabular-nums">{card || "•••• •••• •••• ••••"}</p>
                <p className="mt-4 text-sm">{holder || "Name on card"} · {expiry || "MM/YY"}</p>
              </div>
              <Field label="Card number">
                <TextInput value={card} onChange={(event) => setCard(event.target.value)} inputMode="numeric" autoComplete="off" placeholder="4242 4242 4242 4242" />
              </Field>
              <Field label="Card holder">
                <TextInput value={holder} onChange={(event) => setHolder(event.target.value)} autoComplete="off" />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Expiry">
                  <TextInput value={expiry} onChange={(event) => setExpiry(event.target.value)} placeholder="12/28" autoComplete="off" />
                </Field>
                <Field label="CVV">
                  <TextInput value={cvv} onChange={(event) => setCvv(event.target.value)} inputMode="numeric" autoComplete="off" placeholder="123" />
                </Field>
              </div>
              <p className="text-sm text-muted">Demonstration only. Try 4242 4242 4242 4242, any future expiry, any CVV. The card is not stored and nothing is charged.</p>
              <div className="flex gap-3">
                <GhostButton type="button" onClick={() => setStep("details")}>Back</GhostButton>
                <GoldButton type="submit" disabled={busy}>{busy ? "Taking payment…" : `Pay ${formatLkr(total)}`}</GoldButton>
              </div>
            </form>
          ) : null}
          {error ? <Note>{error}</Note> : null}
        </section>

        <aside className="h-fit rounded-2xl border border-line bg-surface p-5 lg:sticky lg:top-24">
          <p className="text-xs tracking-widest text-gold">THIS TICKET</p>
          <p className="mt-3 font-display text-3xl">{movie.title}</p>
          <p className="mt-2 text-sm text-muted">{formatDay(showtime.show_date)} · {formatClock(showtime.start_time)}</p>
          <p className="text-sm text-muted">{showtime.hall_id} · {showtime.format} · {formatLkr(showtime.ticket_price)} each</p>
          <p className="mt-4 text-sm">Seats</p>
          <p className="text-lg">{codes.length ? codes.join(", ") : "None yet"}</p>
          <p className="mt-4 text-sm text-muted">{selected.length} {selected.length === 1 ? "ticket" : "tickets"}</p>
          <p className="font-display text-4xl tabular-nums">{formatLkr(total)}</p>
          {step === "seats" ? (
            <GoldButton
              className="mt-5 w-full"
              disabled={selected.length === 0 || movie.status !== "Now Showing"}
              onClick={() => {
                setError("");
                setStep("details");
              }}
            >
              Continue
            </GoldButton>
          ) : null}
        </aside>
      </div>
    </Shell>
  );
}
