import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Pending, Shell } from "@/components/cinema/shell";
import { getMovie } from "@/lib/cinema/api";
import { formatClock, formatDay, formatDuration, formatLkr, youtubeId } from "@/lib/cinema/rules";

export const Route = createFileRoute("/movies/$movieId")({
  loader: ({ params }) => getMovie({ data: { id: Number(params.movieId) } }),
  pendingComponent: Pending,
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData?.movie ? `${loaderData.movie.title} — Nexora` : "Film — Nexora" }],
  }),
  component: MoviePage,
});

function MoviePage() {
  const data = Route.useLoaderData();
  if (!data) {
    return (
      <Shell>
        <p className="px-6 py-24 text-muted">That film is not on the programme.</p>
      </Shell>
    );
  }
  return <MovieBody data={data} />;
}

function MovieBody({ data }: { data: NonNullable<Awaited<ReturnType<typeof getMovie>>> }) {
  const { movie, showtimes } = data;
  const dates = useMemo(() => [...new Set(showtimes.map((show) => show.show_date))], [showtimes]);
  const [date, setDate] = useState(dates[0] ?? "");
  const dayShows = showtimes.filter((show) => show.show_date === date);
  const trailer = youtubeId(movie.trailer_url);
  const soon = movie.status === "Coming Soon";

  return (
    <Shell>
      <article className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[280px_1fr]">
        <img src={movie.poster_url} alt="" className="w-full rounded-2xl border border-line object-cover" />
        <div>
          <p className="text-xs tracking-widest text-gold">{movie.status.toUpperCase()}</p>
          <h1 className="mt-2 font-display text-6xl leading-none">{movie.title}</h1>
          <p className="mt-3 text-muted">
            {movie.genre} · {formatDuration(movie.duration_min)} · {movie.format}
            {soon ? ` · Opens ${formatDay(movie.release_date)}` : ""}
          </p>
          <p className="mt-5 max-w-2xl text-lg">{movie.description}</p>
          {movie.format === "3D" ? (
            <p className="mt-4 text-sm text-gold">3D plays in C1 and C2 only. C3 stays dark for this format.</p>
          ) : null}

          <div className="mt-8 overflow-hidden rounded-2xl border border-line bg-black">
            {trailer ? (
              <iframe
                className="aspect-video w-full"
                src={`https://www.youtube-nocookie.com/embed/${trailer}`}
                title={`${movie.title} trailer`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <p className="p-6 text-muted">The trailer link is not a YouTube address yet.</p>
            )}
          </div>
          <p className="mt-2 text-xs text-muted">House preview reel. Staff can replace the link.</p>
        </div>
      </article>

      <section className="mx-auto max-w-6xl px-4 pb-8 sm:px-6">
        <h2 className="font-display text-4xl">{soon ? "Not open yet" : "Choose a screening"}</h2>
        {soon ? (
          <p className="mt-3 max-w-xl text-muted">
            Coming soon titles stay off the booking board until staff marks them Now Showing.
          </p>
        ) : dates.length === 0 ? (
          <p className="mt-3 text-muted">No screenings are on the board for the days ahead.</p>
        ) : (
          <>
            <div className="mt-5 flex gap-2 overflow-x-auto pb-2">
              {dates.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setDate(item)}
                  className={`min-h-11 shrink-0 rounded-full px-4 ${item === date ? "bg-gold text-bg" : "border border-line text-cream"}`}
                >
                  {formatDay(item)}
                </button>
              ))}
            </div>
            <div className="mt-4 grid gap-3">
              {dayShows.map((show) => (
                <Link
                  key={show.id}
                  to="/book/$showtimeId"
                  params={{ showtimeId: String(show.id) }}
                  className="grid gap-2 rounded-2xl border border-line bg-surface p-4 sm:grid-cols-[7rem_1fr_auto] sm:items-center"
                >
                  <p className="font-display text-3xl tabular-nums">{formatClock(show.start_time)}</p>
                  <div>
                    <p className="text-cream">{show.hall_id} · {show.hall_name}</p>
                    <p className="text-sm text-muted">{show.projection} · {show.sound} · {show.format}</p>
                  </div>
                  <p className="text-gold tabular-nums">{formatLkr(show.ticket_price)}</p>
                </Link>
              ))}
            </div>
          </>
        )}
      </section>
    </Shell>
  );
}
