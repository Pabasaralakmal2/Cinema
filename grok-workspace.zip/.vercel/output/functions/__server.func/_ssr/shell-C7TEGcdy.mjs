import { C as require_jsx_runtime, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-C7TEGcdy.js
var import_jsx_runtime = require_jsx_runtime();
var links = [
	{
		to: "/",
		label: "Films"
	},
	{
		to: "/contact",
		label: "Contact"
	},
	{
		to: "/tickets",
		label: "Tickets"
	},
	{
		to: "/staff",
		label: "Staff"
	}
];
function Shell({ children }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-6 gap-y-3 px-4 py-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "leading-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-3xl tracking-widest",
							children: "NEXORA"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-xs tracking-widest text-gold",
							children: "DOLBY CINEMA"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-wrap gap-x-5 gap-y-2 text-sm",
						children: links.map((link) => {
							const active = link.to === "/" ? pathname === "/" : pathname.startsWith(link.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: link.to,
								className: active ? "text-gold" : "text-cream hover:text-gold",
								children: link.label
							}, link.to);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mt-20 border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-2 px-4 py-10 text-sm text-muted sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl tracking-wide text-cream",
							children: "Where stories become worlds."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "12 Galle Face Terrace, Colombo 03 · +94 11 555 0190 · hello@nexora.cinema" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Open daily 9:30 AM – 11:30 PM. A fictional house for this project." })
					]
				})
			})
		]
	});
}
function Pending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-6 py-24 text-muted",
		children: "Opening the house…"
	}) });
}
//#endregion
export { Shell as n, Pending as t };
