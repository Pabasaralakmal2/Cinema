import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Shell } from "@/components/cinema/shell";
import { Area, Field, GhostButton, GoldButton, Note, SelectInput, TextInput } from "@/components/cinema/ui";
import {
  deleteCustomer,
  deleteMovie,
  deleteShowtime,
  saveMovie,
  saveShowtime,
  setBookingStatus,
  staffDesk,
  updateCustomer,
  verifyTicket,
  type StaffBundle,
} from "@/lib/cinema/api";
import { formatClock, formatDay, formatDuration, formatLkr, GENRES, priceFor } from "@/lib/cinema/rules";
import type { Format, MovieStatus } from "@/lib/cinema/rules";
import type { CustomerRow, Movie, MovieInput } from "@/lib/cinema/types";

export const Route = createFileRoute("/staff")({
  component: StaffPage,
});

const sections = ["Dashboard", "Movies", "Showtimes", "Halls", "Bookings", "Customers", "Verify"] as const;
type Section = (typeof sections)[number];

const emptyMovie = (): MovieInput => ({
  title: "",
  genre: "Drama",
  durationMin: 120,
  description: "",
  posterUrl: "/films/eclipse-meridian.jpg",
  trailerUrl: "https://www.youtube.com/watch?v=R6MlUcmOul8",
  format: "2D",
  releaseDate: new Date().toISOString().slice(0, 10),
  status: "Now Showing",
});

function StaffPage() {
  const [code, setCode] = useState("");
  const [house, setHouse] = useState("");
  const [desk, setDesk] = useState<StaffBundle | null>(null);
  const [section, setSection] = useState<Section>("Dashboard");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const saved = sessionStorage.getItem("nexora-house");
    if (saved) {
      setHouse(saved);
      setCode(saved);
    }
  }, []);

  async function run<T>(fn: () => Promise<T>) {
    setBusy(true);
    setError("");
    try {
      return await fn();
    } catch (err) {
      setError(err instanceof Error ? err.message : "The desk could not complete that.");
      return null;
    } finally {
      setBusy(false);
    }
  }

  async function enter(nextCode: string) {
    const bundle = await run(() => staffDesk({ data: { code: nextCode } }));
    if (!bundle) return;
    sessionStorage.setItem("nexora-house", nextCode);
    setHouse(nextCode);
    setDesk(bundle);
  }

  function apply(bundle: StaffBundle | null) {
    if (bundle) setDesk(bundle);
  }

  if (!desk) {
    return (
      <Shell>
        <section className="mx-auto max-w-md px-4 py-20 sm:px-6">
          <p className="text-xs tracking-widest text-gold">STAFF</p>
          <h1 className="mt-2 font-display text-5xl">House desk</h1>
          <p className="mt-3 text-muted">The demonstration house code is NEXORA.</p>
          <form
            className="mt-8 grid gap-4"
            onSubmit={(event) => {
              event.preventDefault();
              void enter(code);
            }}
          >
            <Field label="House code">
              <TextInput type="password" value={code} onChange={(event) => setCode(event.target.value)} autoComplete="current-password" />
            </Field>
            {error ? <Note>{error}</Note> : null}
            <GoldButton type="submit" disabled={busy}>{busy ? "Checking…" : "Enter"}</GoldButton>
          </form>
        </section>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:px-6 lg:grid-cols-[12rem_1fr]">
        <nav className="flex flex-wrap gap-2 lg:flex-col">
          {sections.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => { setSection(item); setError(""); }}
              className={`min-h-11 rounded-full px-4 text-left ${section === item ? "bg-gold text-bg" : "border border-line text-cream"}`}
            >
              {item}
            </button>
          ))}
          <GhostButton
            onClick={() => {
              sessionStorage.removeItem("nexora-house");
              setDesk(null);
              setHouse("");
            }}
          >
            Leave
          </GhostButton>
        </nav>
        <section>
          {error ? <Note>{error}</Note> : null}
          {section === "Dashboard" ? <Dashboard desk={desk} /> : null}
          {section === "Movies" ? (
            <Movies desk={desk} house={house} busy={busy} onDone={apply} run={run} />
          ) : null}
          {section === "Showtimes" ? (
            <Showtimes desk={desk} house={house} busy={busy} onDone={apply} run={run} />
          ) : null}
          {section === "Halls" ? <Halls desk={desk} /> : null}
          {section === "Bookings" ? (
            <Bookings desk={desk} house={house} busy={busy} onDone={apply} run={run} />
          ) : null}
          {section === "Customers" ? (
            <Customers desk={desk} house={house} busy={busy} onDone={apply} run={run} />
          ) : null}
          {section === "Verify" ? <Verify house={house} /> : null}
        </section>
      </div>
    </Shell>
  );
}

function Dashboard({ desk }: { desk: StaffBundle }) {
  const cards = [
    ["Films", desk.stats.movies],
    ["Now showing", desk.stats.now_showing],
    ["Coming soon", desk.stats.coming_soon],
    ["Bookings", desk.stats.bookings],
    ["Today’s shows", desk.stats.today],
    ["Guests", desk.stats.customers],
  ] as const;
  return (
    <div>
      <h1 className="font-display text-5xl">Tonight’s board</h1>
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3">
        {cards.map(([label, value]) => (
          <article key={label} className="rounded-2xl border border-line bg-surface p-4">
            <p className="text-sm text-muted">{label}</p>
            <p className="font-display text-4xl tabular-nums">{value}</p>
          </article>
        ))}
      </div>
    </div>
  );
}

function Movies({
  desk, house, busy, onDone, run,
}: {
  desk: StaffBundle;
  house: string;
  busy: boolean;
  onDone: (bundle: StaffBundle | null) => void;
  run: <T>(fn: () => Promise<T>) => Promise<T | null>;
}) {
  const [draft, setDraft] = useState<MovieInput>(emptyMovie());
  const [query, setQuery] = useState("");
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const films = desk.movies.filter((movie) => movie.title.toLowerCase().includes(query.trim().toLowerCase()) || movie.genre.toLowerCase().includes(query.trim().toLowerCase()));

  function edit(movie: Movie) {
    setDraft({
      id: movie.id,
      title: movie.title,
      genre: movie.genre,
      durationMin: movie.duration_min,
      description: movie.description,
      posterUrl: movie.poster_url,
      trailerUrl: movie.trailer_url,
      format: movie.format,
      releaseDate: movie.release_date,
      status: movie.status,
    });
  }

  return (
    <div className="grid gap-8">
      <div>
        <h1 className="font-display text-5xl">{draft.id ? "Update film" : "Add a film"}</h1>
        <form
          className="mt-5 grid gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            void run(() => saveMovie({ data: { code: house, movie: draft } })).then(onDone);
          }}
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Title"><TextInput value={draft.title} onChange={(event) => setDraft({ ...draft, title: event.target.value })} /></Field>
            <Field label="Genre">
              <TextInput list="genres" value={draft.genre} onChange={(event) => setDraft({ ...draft, genre: event.target.value })} />
              <datalist id="genres">{GENRES.map((genre) => <option key={genre} value={genre} />)}</datalist>
            </Field>
            <Field label="Runtime in minutes"><TextInput type="number" value={draft.durationMin} onChange={(event) => setDraft({ ...draft, durationMin: Number(event.target.value) })} /></Field>
            <Field label="Format">
              <SelectInput value={draft.format} onChange={(event) => setDraft({ ...draft, format: event.target.value as Format })}>
                <option>2D</option>
                <option>3D</option>
              </SelectInput>
            </Field>
            <Field label="Release date"><TextInput type="date" value={draft.releaseDate} onChange={(event) => setDraft({ ...draft, releaseDate: event.target.value })} /></Field>
            <Field label="Status">
              <SelectInput value={draft.status} onChange={(event) => setDraft({ ...draft, status: event.target.value as MovieStatus })}>
                <option>Now Showing</option>
                <option>Coming Soon</option>
              </SelectInput>
            </Field>
          </div>
          <Field label="Poster address"><TextInput value={draft.posterUrl} onChange={(event) => setDraft({ ...draft, posterUrl: event.target.value })} /></Field>
          <Field label="Trailer address"><TextInput value={draft.trailerUrl} onChange={(event) => setDraft({ ...draft, trailerUrl: event.target.value })} /></Field>
          <Field label="Description"><Area value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value })} /></Field>
          <p className="text-sm text-muted">Shows as {formatDuration(Number(draft.durationMin) || 0)}.</p>
          <div className="flex flex-wrap gap-3">
            <GoldButton type="submit" disabled={busy}>{draft.id ? "Save changes" : "Add film"}</GoldButton>
            {draft.id ? <GhostButton type="button" onClick={() => setDraft(emptyMovie())}>Clear</GhostButton> : null}
          </div>
        </form>
      </div>
      <div>
        <TextInput value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search films" aria-label="Search films" />
        <ul className="mt-4 grid gap-3">
          {films.map((movie) => (
            <li key={movie.id} className="rounded-2xl border border-line bg-surface p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-display text-3xl">{movie.title}</p>
                  <p className="text-sm text-muted">{movie.genre} · {formatDuration(movie.duration_min)} · {movie.format} · {movie.status}</p>
                </div>
                <div className="flex gap-2">
                  <GhostButton type="button" onClick={() => edit(movie)}>Edit</GhostButton>
                  {confirmId === movie.id ? (
                    <GoldButton type="button" disabled={busy} onClick={() => void run(() => deleteMovie({ data: { code: house, id: movie.id } })).then((bundle) => { setConfirmId(null); onDone(bundle); })}>Confirm delete</GoldButton>
                  ) : (
                    <GhostButton type="button" onClick={() => setConfirmId(movie.id)}>Delete</GhostButton>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function Showtimes({
  desk, house, busy, onDone, run,
}: {
  desk: StaffBundle;
  house: string;
  busy: boolean;
  onDone: (bundle: StaffBundle | null) => void;
  run: <T>(fn: () => Promise<T>) => Promise<T | null>;
}) {
  const showing = desk.movies.filter((movie) => movie.status === "Now Showing");
  const [movieId, setMovieId] = useState(showing[0]?.id ?? 0);
  const [hallId, setHallId] = useState("C1");
  const [showDate, setShowDate] = useState(desk.showtimes[0]?.show_date ?? "");
  const [startTime, setStartTime] = useState("18:00");
  const [editing, setEditing] = useState<number | undefined>(undefined);
  const movie = desk.movies.find((item) => item.id === Number(movieId));
  const price = movie ? priceFor(hallId, movie.format) : null;
  const halls = desk.halls.filter((hall) => movie?.format !== "3D" || hall.supports_3d);

  return (
    <div>
      <h1 className="font-display text-5xl">{editing ? "Update screening" : "Add a screening"}</h1>
      <form
        className="mt-5 grid gap-3 sm:grid-cols-2"
        onSubmit={(event) => {
          event.preventDefault();
          void run(() => saveShowtime({
            data: { code: house, show: { id: editing, movieId: Number(movieId), hallId, showDate, startTime } },
          })).then((bundle) => {
            if (bundle) {
              setEditing(undefined);
              onDone(bundle);
            }
          });
        }}
      >
        <Field label="Film">
          <SelectInput value={movieId} onChange={(event) => setMovieId(Number(event.target.value))}>
            {showing.map((item) => <option key={item.id} value={item.id}>{item.title} · {item.format}</option>)}
          </SelectInput>
        </Field>
        <Field label="Hall">
          <SelectInput value={hallId} onChange={(event) => setHallId(event.target.value)}>
            {halls.map((hall) => <option key={hall.id} value={hall.id}>{hall.id} · {hall.name}</option>)}
          </SelectInput>
        </Field>
        <Field label="Date"><TextInput type="date" value={showDate} onChange={(event) => setShowDate(event.target.value)} /></Field>
        <Field label="Start"><TextInput type="time" value={startTime} onChange={(event) => setStartTime(event.target.value)} /></Field>
        <p className="sm:col-span-2 text-sm text-gold">{price == null ? "C3 cannot take a 3D film." : `Price ${formatLkr(price)} · set by the house, not by the form.`}</p>
        <div className="flex gap-3 sm:col-span-2">
          <GoldButton type="submit" disabled={busy || price == null}>{editing ? "Save screening" : "Add screening"}</GoldButton>
          {editing ? <GhostButton type="button" onClick={() => setEditing(undefined)}>Clear</GhostButton> : null}
        </div>
      </form>
      <ul className="mt-6 grid gap-3">
        {desk.showtimes.map((show) => (
          <li key={show.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-4">
            <div>
              <p>{show.movie_title}</p>
              <p className="text-sm text-muted">{formatDay(show.show_date)} · {formatClock(show.start_time)} · {show.hall_id} · {show.format} · {formatLkr(show.ticket_price)}</p>
            </div>
            <div className="flex gap-2">
              <GhostButton type="button" onClick={() => { setEditing(show.id); setMovieId(show.movie_id); setHallId(show.hall_id); setShowDate(show.show_date); setStartTime(show.start_time); }}>Edit</GhostButton>
              <GhostButton type="button" disabled={busy} onClick={() => void run(() => deleteShowtime({ data: { code: house, id: show.id } })).then(onDone)}>Delete</GhostButton>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Halls({ desk }: { desk: StaffBundle }) {
  return (
    <div>
      <h1 className="font-display text-5xl">Halls</h1>
      <p className="mt-2 text-muted">Prices and 3D rights are house rules. C3 never takes a 3D print.</p>
      <div className="mt-6 grid gap-3">
        {desk.halls.map((hall) => (
          <article key={hall.id} className="rounded-2xl border border-line bg-surface p-5">
            <h2 className="font-display text-3xl">{hall.id} · {hall.name}</h2>
            <p className="text-sm text-muted">{hall.projection} · {hall.sound} · {hall.capacity} seats</p>
            <p className="mt-2">2D {formatLkr(hall.price_2d)} · {hall.supports_3d && hall.price_3d != null ? `3D ${formatLkr(hall.price_3d)}` : "3D not available"}</p>
          </article>
        ))}
      </div>
    </div>
  );
}

function Bookings({
  desk, house, busy, onDone, run,
}: {
  desk: StaffBundle;
  house: string;
  busy: boolean;
  onDone: (bundle: StaffBundle | null) => void;
  run: <T>(fn: () => Promise<T>) => Promise<T | null>;
}) {
  const [query, setQuery] = useState("");
  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return desk.bookings;
    return desk.bookings.filter((row) =>
      `${row.ticket_code} ${row.full_name} ${row.movie_title} ${row.show_date} ${row.hall_id}`.toLowerCase().includes(q),
    );
  }, [desk.bookings, query]);
  return (
    <div>
      <h1 className="font-display text-5xl">Bookings</h1>
      <TextInput className="mt-4" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search code, guest, film, or date" aria-label="Search bookings" />
      <ul className="mt-4 grid gap-3">
        {rows.map((row) => (
          <li key={row.id} className="rounded-2xl border border-line bg-surface p-4">
            <p className="text-gold">{row.ticket_code}</p>
            <p className="font-display text-3xl">{row.movie_title}</p>
            <p className="text-sm text-muted">{row.full_name} · {row.phone} · {row.email}</p>
            <p className="text-sm">{formatDay(row.show_date)} · {formatClock(row.start_time)} · {row.hall_id} · {row.format} · {row.seat_list}</p>
            <p className="tabular-nums">{formatLkr(row.total_amount)} · {row.payment_status} · {row.booking_status}</p>
            {row.booking_status === "Confirmed" ? (
              <div className="mt-3 flex flex-wrap gap-2">
                <GhostButton type="button" disabled={busy} onClick={() => void run(() => setBookingStatus({ data: { code: house, id: row.id, status: "Used" } })).then(onDone)}>Mark used</GhostButton>
                <GhostButton type="button" disabled={busy} onClick={() => void run(() => setBookingStatus({ data: { code: house, id: row.id, status: "Cancelled" } })).then(onDone)}>Cancel and free seats</GhostButton>
              </div>
            ) : null}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Customers({
  desk, house, busy, onDone, run,
}: {
  desk: StaffBundle;
  house: string;
  busy: boolean;
  onDone: (bundle: StaffBundle | null) => void;
  run: <T>(fn: () => Promise<T>) => Promise<T | null>;
}) {
  const [query, setQuery] = useState("");
  const [edit, setEdit] = useState<CustomerRow | null>(null);
  const rows = desk.customers.filter((row) => `${row.full_name} ${row.email} ${row.phone}`.toLowerCase().includes(query.trim().toLowerCase()));
  return (
    <div>
      <h1 className="font-display text-5xl">Guests</h1>
      <TextInput className="mt-4" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search guests" aria-label="Search guests" />
      {edit ? (
        <form
          className="mt-4 grid gap-3 rounded-2xl border border-line bg-surface p-4"
          onSubmit={(event) => {
            event.preventDefault();
            void run(() => updateCustomer({
              data: { code: house, id: edit.id, person: { fullName: edit.full_name, phone: edit.phone, email: edit.email } },
            })).then((bundle) => { if (bundle) { setEdit(null); onDone(bundle); } });
          }}
        >
          <Field label="Name"><TextInput value={edit.full_name} onChange={(event) => setEdit({ ...edit, full_name: event.target.value })} /></Field>
          <Field label="Phone"><TextInput value={edit.phone} onChange={(event) => setEdit({ ...edit, phone: event.target.value })} /></Field>
          <Field label="Email"><TextInput value={edit.email} onChange={(event) => setEdit({ ...edit, email: event.target.value })} /></Field>
          <div className="flex gap-2">
            <GoldButton type="submit" disabled={busy}>Save guest</GoldButton>
            <GhostButton type="button" onClick={() => setEdit(null)}>Close</GhostButton>
          </div>
        </form>
      ) : null}
      <ul className="mt-4 grid gap-3">
        {rows.map((row) => (
          <li key={row.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-4">
            <div>
              <p>{row.full_name}</p>
              <p className="text-sm text-muted">{row.phone} · {row.email} · {row.bookings} bookings</p>
            </div>
            <div className="flex gap-2">
              <GhostButton type="button" onClick={() => setEdit(row)}>Edit</GhostButton>
              <GhostButton type="button" disabled={busy || row.bookings > 0} onClick={() => void run(() => deleteCustomer({ data: { code: house, id: row.id } })).then(onDone)}>Delete</GhostButton>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Verify({ house }: { house: string }) {
  const [ticketCode, setTicketCode] = useState("");
  const [message, setMessage] = useState("");
  const [ok, setOk] = useState<boolean | null>(null);
  return (
    <div>
      <h1 className="font-display text-5xl">Check a ticket</h1>
      <form
        className="mt-5 grid max-w-md gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          void verifyTicket({ data: { code: house, ticketCode } })
            .then((ticket) => {
              if (!ticket) {
                setOk(false);
                setMessage("No ticket matches that code.");
                return;
              }
              setOk(ticket.verdict === "valid");
              setMessage(ticket.verdict === "valid"
                ? `Valid ticket. ${ticket.title}, ${ticket.seats}, ${ticket.hall_id}.`
                : `Invalid or used. Status: ${ticket.booking_status}.`);
            })
            .catch((err: unknown) => {
              setOk(false);
              setMessage(err instanceof Error ? err.message : "Could not check that ticket.");
            });
        }}
      >
        <Field label="Booking code"><TextInput value={ticketCode} onChange={(event) => setTicketCode(event.target.value)} /></Field>
        <GoldButton type="submit" className="w-fit">Check</GoldButton>
      </form>
      {ok != null ? <p className={`mt-4 ${ok ? "text-gold" : "text-alert"}`}>{message}</p> : null}
    </div>
  );
}
