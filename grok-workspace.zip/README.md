# Nexora Dolby Cinema

Where stories become worlds.

A cinema desk for three houses: programme, trailers, seat maps, simulated card payment, QR tickets, and a staff desk with film and screening records.

## Houses

| Hall | Picture | Sound | 2D | 3D |
| --- | --- | --- | --- | --- |
| C1 NEXORA Dolby Cinema | 8K Laser | Dolby Atmos | LKR 1,500 | LKR 1,800 |
| C2 House Two | 2K | 7.1 | LKR 1,300 | LKR 1,500 |
| C3 House Three | 2K | 7.1 | LKR 1,300 | Not available |

A seat is taken only for one film, one date, one time, and one hall. Coming soon titles cannot be booked. C3 cannot be given a 3D screening.

## Staff

Open Staff and enter the house code **NEXORA**. From there you can add, edit, and delete films and screenings, read bookings and guests, cancel a booking (which frees the seats), and check a ticket code.

Card numbers are checked on the payment screen and are not saved. The demonstration card is `4242 4242 4242 4242`.

## Records

Films, halls, seats, screenings, guests, bookings, booking seats, and payments live in PostgreSQL. The schema is in `migrations/0002_cinema.sql`.
