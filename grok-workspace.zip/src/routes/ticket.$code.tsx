import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { Pending, Shell } from "@/components/cinema/shell";
import { GoldButton } from "@/components/cinema/ui";
import { getTicket } from "@/lib/cinema/api";
import { formatClock, formatDay, formatLkr } from "@/lib/cinema/rules";
import type { Ticket } from "@/lib/cinema/types";

export const Route = createFileRoute("/ticket/$code")({
  loader: ({ params }) => getTicket({ data: { code: params.code } }),
  pendingComponent: Pending,
  component: TicketPage,
});

function payload(ticket: Ticket) {
  return [
    "NEXORA DOLBY CINEMA",
    ticket.ticket_code,
    ticket.title,
    `${ticket.show_date} ${ticket.start_time}`,
    `${ticket.hall_id} ${ticket.format}`,
    `Seats: ${ticket.seats}`,
    ticket.full_name,
  ].join("\n");
}

function TicketPage() {
  const ticket = Route.useLoaderData();
  const [qr, setQr] = useState("");

  useEffect(() => {
    if (!ticket) return;
    let live = true;
    void QRCode.toDataURL(payload(ticket), {
      margin: 1,
      width: 320,
      color: { dark: "#14110e", light: "#f3ecdf" },
    }).then((url) => {
      if (live) setQr(url);
    });
    return () => {
      live = false;
    };
  }, [ticket]);

  if (!ticket) {
    return (
      <Shell>
        <p className="px-6 py-24 text-muted">No ticket matches that code.</p>
      </Shell>
    );
  }

  const pass = ticket;

  async function save() {
    if (!qr) return;
    await document.fonts.ready;
    const canvas = document.createElement("canvas");
    canvas.width = 1200;
    canvas.height = 560;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#14110e";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#c6a36a";
    ctx.strokeRect(24, 24, canvas.width - 48, canvas.height - 48);
    ctx.fillStyle = "#c6a36a";
    ctx.font = "500 22px Outfit, sans-serif";
    ctx.fillText("NEXORA DOLBY CINEMA", 64, 88);
    ctx.fillStyle = "#f3ecdf";
    ctx.font = "600 64px Cormorant Garamond, serif";
    ctx.fillText(pass.title, 64, 170);
    ctx.font = "400 28px Outfit, sans-serif";
    const lines = [
      `${formatDay(pass.show_date)}  ·  ${formatClock(pass.start_time)}`,
      `${pass.hall_id}  ${pass.hall_name}  ·  ${pass.format}`,
      `Seats  ${pass.seats}`,
      pass.full_name,
      formatLkr(pass.total_amount),
      pass.ticket_code,
    ];
    lines.forEach((line, index) => ctx.fillText(line, 64, 230 + index * 42));
    const img = new Image();
    img.onload = () => {
      ctx.drawImage(img, 900, 160, 220, 220);
      const link = document.createElement("a");
      link.href = canvas.toDataURL("image/png");
      link.download = `${pass.ticket_code}.png`;
      link.click();
    };
    img.src = qr;
  }

  const valid = pass.verdict === "valid";

  return (
    <Shell>
      <section className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
        <p className="text-xs tracking-widest text-gold">{valid ? "BOOKING CONFIRMED" : ticket.booking_status.toUpperCase()}</p>
        <h1 className="mt-2 font-display text-5xl">Your ticket</h1>
        <article className="mt-8 grid gap-6 rounded-2xl border border-gold bg-surface p-6 sm:grid-cols-[1fr_180px]">
          <div>
            <p className="font-display text-4xl">{ticket.title}</p>
            <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div><dt className="text-muted">Date</dt><dd>{formatDay(ticket.show_date)}</dd></div>
              <div><dt className="text-muted">Time</dt><dd className="tabular-nums">{formatClock(ticket.start_time)}</dd></div>
              <div><dt className="text-muted">Hall</dt><dd>{ticket.hall_id} · {ticket.hall_name}</dd></div>
              <div><dt className="text-muted">Format</dt><dd>{ticket.format}</dd></div>
              <div><dt className="text-muted">Seats</dt><dd>{ticket.seats}</dd></div>
              <div><dt className="text-muted">Guest</dt><dd>{ticket.full_name}</dd></div>
              <div><dt className="text-muted">Total</dt><dd className="tabular-nums">{formatLkr(ticket.total_amount)}</dd></div>
              <div><dt className="text-muted">Booking</dt><dd>{ticket.ticket_code}</dd></div>
            </dl>
            <p className="mt-4 text-sm text-muted">{ticket.projection} · {ticket.sound}</p>
          </div>
          <div className="flex flex-col items-center justify-center">
            {qr ? <img src={qr} alt={`QR code for ${ticket.ticket_code}`} className="w-40 rounded-lg bg-cream p-2" /> : <p className="text-sm text-muted">Drawing the code…</p>}
          </div>
        </article>
        <GoldButton className="mt-6" onClick={() => void save()} disabled={!qr}>Save ticket</GoldButton>
      </section>
    </Shell>
  );
}
