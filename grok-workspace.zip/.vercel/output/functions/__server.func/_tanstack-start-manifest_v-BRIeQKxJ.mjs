//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BRIeQKxJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/contact",
			"/staff",
			"/tickets",
			"/book/$showtimeId",
			"/movies/$movieId",
			"/ticket/$code"
		],
		preloads: [
			"/assets/index-Vboyz2J5.js",
			"/assets/shell-iOAnQnRY.js",
			"/assets/api-pJMT-nq_.js",
			"/assets/preload-helper-DpmBmfpA.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Vboyz2J5.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DVkwLhNA.js", "/assets/rules-ESH9IqOv.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-C4s40gJQ.js"]
	},
	"/staff": {
		filePath: "/workspace/src/routes/staff.tsx",
		children: void 0,
		preloads: [
			"/assets/staff-Dp8XL-1j.js",
			"/assets/ui-Cty-BXmr.js",
			"/assets/rules-ESH9IqOv.js"
		]
	},
	"/tickets": {
		filePath: "/workspace/src/routes/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-D9BVfeEI.js",
			"/assets/useNavigate-DH92pYlV.js",
			"/assets/ui-Cty-BXmr.js"
		]
	},
	"/book/$showtimeId": {
		filePath: "/workspace/src/routes/book.$showtimeId.tsx",
		children: void 0,
		preloads: [
			"/assets/book._showtimeId-2liC9neD.js",
			"/assets/ui-Cty-BXmr.js",
			"/assets/rules-ESH9IqOv.js"
		]
	},
	"/movies/$movieId": {
		filePath: "/workspace/src/routes/movies.$movieId.tsx",
		children: void 0,
		preloads: ["/assets/movies._movieId-BZf8iqXI.js", "/assets/rules-ESH9IqOv.js"]
	},
	"/ticket/$code": {
		filePath: "/workspace/src/routes/ticket.$code.tsx",
		children: void 0,
		preloads: [
			"/assets/ticket._code-D3sUfN9x.js",
			"/assets/ui-Cty-BXmr.js",
			"/assets/rules-ESH9IqOv.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
