import type { Format, MovieStatus } from "@/lib/cinema/rules";

export type Movie = {
  id: number;
  title: string;
  genre: string;
  duration_min: number;
  description: string;
  poster_url: string;
  trailer_url: string;
  format: Format;
  release_date: string;
  status: MovieStatus;
};

export type Hall = {
  id: string;
  name: string;
  tagline: string;
  projection: string;
  sound: string;
  supports_3d: boolean;
  capacity: number;
  price_2d: number;
  price_3d: number | null;
};

export type Showtime = {
  id: number;
  movie_id: number;
  hall_id: string;
  show_date: string;
  start_time: string;
  format: Format;
  ticket_price: number;
  hall_name: string;
  projection: string;
  sound: string;
  movie_title?: string;
  duration_min?: number;
};

export type Seat = {
  id: number;
  row_label: string;
  seat_number: number;
  seat_code: string;
  status: "available" | "booked";
};

export type Ticket = {
  ticket_code: string;
  full_name: string;
  title: string;
  show_date: string;
  start_time: string;
  hall_id: string;
  hall_name: string;
  projection: string;
  sound: string;
  format: Format;
  seats: string;
  total_amount: number;
  payment_status: string;
  booking_status: string;
  verdict: "valid" | "invalid";
};

export type Stats = {
  movies: number;
  now_showing: number;
  coming_soon: number;
  bookings: number;
  today: number;
  customers: number;
};

export type BookingRow = {
  id: number;
  ticket_code: string;
  total_amount: number;
  payment_status: string;
  booking_status: string;
  seat_list: string;
  full_name: string;
  phone: string;
  email: string;
  customer_id: number;
  movie_title: string;
  hall_id: string;
  show_date: string;
  start_time: string;
  format: Format;
};

export type CustomerRow = {
  id: number;
  full_name: string;
  phone: string;
  email: string;
  bookings: number;
};

export type MovieInput = {
  id?: number;
  title: string;
  genre: string;
  durationMin: number;
  description: string;
  posterUrl: string;
  trailerUrl: string;
  format: Format;
  releaseDate: string;
  status: MovieStatus;
};

export type ShowtimeInput = {
  id?: number;
  movieId: number;
  hallId: string;
  showDate: string;
  startTime: string;
};
