import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-C7TEGcdy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-BFT9aH-U.js
var import_jsx_runtime = require_jsx_runtime();
var facts = [
	["Address", "12 Galle Face Terrace, Colombo 03"],
	["Phone", "+94 11 555 0190"],
	["Email", "hello@nexora.cinema"],
	["Hours", "Open daily, 9:30 AM – 11:30 PM"]
];
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-gold",
				children: "CONTACT"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-6xl leading-none",
				children: "Nexora Dolby Cinema"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-display text-3xl text-cream",
				children: "Where stories become worlds."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-md text-muted",
				children: "The box office answers for tickets, school visits, and private hires. This address belongs to the project, not a real theatre."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "grid gap-4",
			children: facts.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-line bg-surface p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs tracking-widest text-gold",
					children: label.toUpperCase()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-2 text-lg",
					children: value
				})]
			}, label))
		})]
	}) });
}
//#endregion
export { ContactPage as component };
