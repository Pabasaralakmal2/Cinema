import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";

const links = [
  { to: "/", label: "Films" },
  { to: "/contact", label: "Contact" },
  { to: "/tickets", label: "Tickets" },
  { to: "/staff", label: "Staff" },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  return (
    <div className="min-h-screen bg-bg text-cream">
      <header className="sticky top-0 z-20 border-b border-line bg-bg">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-6 gap-y-3 px-4 py-4 sm:px-6">
          <Link to="/" className="leading-none">
            <span className="block font-display text-3xl tracking-widest">NEXORA</span>
            <span className="mt-1 block text-xs tracking-widest text-gold">DOLBY CINEMA</span>
          </Link>
          <nav className="flex flex-wrap gap-x-5 gap-y-2 text-sm">
            {links.map((link) => {
              const active = link.to === "/" ? pathname === "/" : pathname.startsWith(link.to);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={active ? "text-gold" : "text-cream hover:text-gold"}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <main>{children}</main>
      <footer className="mt-20 border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-10 text-sm text-muted sm:px-6">
          <p className="font-display text-2xl tracking-wide text-cream">Where stories become worlds.</p>
          <p>12 Galle Face Terrace, Colombo 03 · +94 11 555 0190 · hello@nexora.cinema</p>
          <p>Open daily 9:30 AM – 11:30 PM. A fictional house for this project.</p>
        </div>
      </footer>
    </div>
  );
}

export function Pending() {
  return (
    <Shell>
      <p className="px-6 py-24 text-muted">Opening the house…</p>
    </Shell>
  );
}
