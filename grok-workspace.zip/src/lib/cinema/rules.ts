export const GENRES = [
  "Action",
  "Adventure",
  "Drama",
  "Comedy",
  "Horror",
  "Sci-Fi",
  "Thriller",
  "Romance",
  "Animation",
  "Fantasy",
] as const;

export const HOUSE_CODE = "NEXORA";

export type Format = "2D" | "3D";
export type MovieStatus = "Now Showing" | "Coming Soon";

export function formatDuration(mins: number) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h <= 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

export function formatLkr(amount: number) {
  return `LKR ${amount.toLocaleString("en-US")}`;
}

export function formatClock(hhmm: string) {
  const [hStr, mStr] = hhmm.slice(0, 5).split(":");
  let h = Number(hStr);
  const m = mStr ?? "00";
  const ap = h >= 12 ? "PM" : "AM";
  h = h % 12;
  if (h === 0) h = 12;
  return `${h}:${m} ${ap}`;
}

export function formatDay(iso: string) {
  const [y, mo, d] = iso.slice(0, 10).split("-").map(Number);
  const dt = new Date(Date.UTC(y, (mo || 1) - 1, d || 1));
  return dt.toLocaleDateString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    timeZone: "UTC",
  });
}

export function clockToMinutes(hhmm: string) {
  const [h, m] = hhmm.slice(0, 5).split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}

/** Two screenings overlap when one starts before the other has ended, plus a 20-minute turn. */
export function rangesOverlap(startA: number, durA: number, startB: number, durB: number, gap = 20) {
  return startA < startB + durB + gap && startB < startA + durA + gap;
}

/**
 * House prices. C3 has no 3D lamp, so that combination has no price.
 * C1 2D 1500, C1 3D 1800, C2 2D 1300, C2 3D 1500, C3 2D 1300.
 */
export function priceFor(hallId: string, format: Format): number | null {
  if (hallId === "C1" && format === "2D") return 1500;
  if (hallId === "C1" && format === "3D") return 1800;
  if (hallId === "C2" && format === "2D") return 1300;
  if (hallId === "C2" && format === "3D") return 1500;
  if (hallId === "C3" && format === "2D") return 1300;
  return null;
}

export function youtubeId(url: string): string | null {
  try {
    const u = new URL(url.trim());
    if (u.hostname.includes("youtu.be")) {
      const id = u.pathname.split("/").filter(Boolean)[0] ?? "";
      return id.length >= 11 ? id.slice(0, 11) : null;
    }
    const v = u.searchParams.get("v");
    if (v && v.length >= 11) return v.slice(0, 11);
    const parts = u.pathname.split("/");
    const embed = parts.indexOf("embed");
    if (embed >= 0 && parts[embed + 1] && parts[embed + 1].length >= 11) {
      return parts[embed + 1].slice(0, 11);
    }
  } catch {
    return null;
  }
  return null;
}

export function luhn(num: string) {
  let sum = 0;
  let alt = false;
  for (let i = num.length - 1; i >= 0; i -= 1) {
    let n = Number(num[i]);
    if (Number.isNaN(n)) return false;
    if (alt) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    sum += n;
    alt = !alt;
  }
  return sum % 10 === 0;
}

export function sortSeatCodes(codes: string[]) {
  return [...codes].sort((a, b) => {
    const ra = a.charAt(0);
    const rb = b.charAt(0);
    if (ra !== rb) return ra.charCodeAt(0) - rb.charCodeAt(0);
    return Number(a.slice(1)) - Number(b.slice(1));
  });
}
