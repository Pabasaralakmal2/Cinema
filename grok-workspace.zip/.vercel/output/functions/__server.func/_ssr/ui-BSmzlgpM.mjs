import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-BSmzlgpM.js
var import_jsx_runtime = require_jsx_runtime();
var fieldClass = "min-h-11 w-full rounded-lg border border-line bg-bg px-3 py-2 text-cream placeholder:text-muted";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block",
			children: label
		}), children]
	});
}
function TextInput({ className = "", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: `${fieldClass} ${className}`
	});
}
function Area(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: `${fieldClass} min-h-28`
	});
}
function SelectInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: fieldClass
	});
}
function GoldButton({ className = "", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: `inline-flex min-h-11 items-center justify-center rounded-full bg-gold px-5 font-medium text-bg disabled:opacity-40 ${className}`
	});
}
function GhostButton({ className = "", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: `inline-flex min-h-11 items-center justify-center rounded-full border border-line px-5 text-cream disabled:opacity-40 ${className}`
	});
}
function Note({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-alert",
		children
	});
}
//#endregion
export { Note as a, GoldButton as i, Field as n, SelectInput as o, GhostButton as r, TextInput as s, Area as t };
