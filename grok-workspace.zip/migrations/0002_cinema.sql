-- Nexora Dolby Cinema. PostgreSQL schema shared by preview and deploy.

create table if not exists halls (
  id text primary key,
  name text not null,
  tagline text not null,
  projection text not null,
  sound text not null,
  supports_3d boolean not null,
  capacity integer not null,
  price_2d integer not null,
  price_3d integer
);

create table if not exists seats (
  id serial primary key,
  hall_id text not null references halls(id),
  row_label text not null,
  seat_number integer not null,
  seat_code text not null,
  unique (hall_id, seat_code)
);

create table if not exists movies (
  id serial primary key,
  title text not null,
  genre text not null,
  duration_min integer not null,
  description text not null,
  poster_url text not null,
  trailer_url text not null,
  format text not null check (format in ('2D', '3D')),
  release_date date not null,
  status text not null check (status in ('Now Showing', 'Coming Soon'))
);

create table if not exists showtimes (
  id serial primary key,
  movie_id integer not null references movies(id) on delete cascade,
  hall_id text not null references halls(id),
  show_date date not null,
  start_time text not null,
  format text not null check (format in ('2D', '3D')),
  ticket_price integer not null,
  unique (hall_id, show_date, start_time)
);

create table if not exists customers (
  id serial primary key,
  full_name text not null,
  phone text not null,
  email text not null
);

create table if not exists bookings (
  id serial primary key,
  customer_id integer not null references customers(id),
  showtime_id integer not null references showtimes(id),
  booked_at timestamptz not null default now(),
  total_amount integer not null,
  payment_status text not null,
  booking_status text not null,
  ticket_code text not null unique,
  seat_list text not null
);

create table if not exists booking_seats (
  id serial primary key,
  booking_id integer not null references bookings(id) on delete cascade,
  seat_id integer not null references seats(id),
  showtime_id integer not null references showtimes(id),
  unique (showtime_id, seat_id)
);

create table if not exists payments (
  id serial primary key,
  booking_id integer not null references bookings(id),
  amount integer not null,
  payment_method text not null,
  payment_status text not null,
  transaction_reference text not null,
  payment_date timestamptz not null default now()
);

create index if not exists showtimes_movie_idx on showtimes (movie_id, show_date);
create index if not exists bookings_showtime_idx on bookings (showtime_id);

insert into halls (id, name, tagline, projection, sound, supports_3d, capacity, price_2d, price_3d)
values
  ('C1', 'NEXORA Dolby Cinema', 'The flagship house', '8K Laser', 'Dolby Atmos', true, 140, 1500, 1800),
  ('C2', 'House Two', 'A sharp, close room', '2K Projector', '7.1 Surround', true, 140, 1300, 1500),
  ('C3', 'House Three', '2D only, by design', '2K Projector', '7.1 Surround', false, 140, 1300, null)
on conflict (id) do nothing;

insert into seats (hall_id, row_label, seat_number, seat_code)
select h.id, chr(64 + r.n), s.n, chr(64 + r.n) || s.n::text
from halls h
cross join generate_series(1, 7) as r(n)
cross join generate_series(1, 20) as s(n)
where not exists (select 1 from seats limit 1);

insert into movies (title, genre, duration_min, description, poster_url, trailer_url, format, release_date, status)
select * from (values
  ('Eclipse Meridian', 'Sci-Fi', 169,
   'A survey ship stalls on the lip of a star that should not exist. The crew has one orbit to decide what they are willing to forget.',
   '/films/eclipse-meridian.jpg', 'https://www.youtube.com/watch?v=R6MlUcmOul8', '3D', current_date - 24, 'Now Showing'),
  ('Glass Tide', 'Adventure', 148,
   'When the southern sea turns to black glass, a navigator sails toward a light that keeps moving just under the surface.',
   '/films/glass-tide.jpg', 'https://www.youtube.com/watch?v=Y-rmzh0PI3c', '2D', current_date - 40, 'Now Showing'),
  ('Velvet Static', 'Thriller', 118,
   'A night editor uncovers a broadcast that plays only for people who are about to disappear.',
   '/films/velvet-static.jpg', 'https://www.youtube.com/watch?v=TLkA0RELQ1g', '2D', current_date - 12, 'Now Showing'),
  ('Crown of Ash', 'Fantasy', 156,
   'The last coronation in a burned kingdom is performed for an empty throne, and the crown still answers.',
   '/films/crown-of-ash.jpg', 'https://www.youtube.com/watch?v=eRsGyueVLvQ', '3D', current_date - 18, 'Now Showing'),
  ('Paper Moons', 'Romance', 112,
   'Two strangers trade paper boats across a night harbor, each one carrying a promise they are not ready to say aloud.',
   '/films/paper-moons.jpg', 'https://www.youtube.com/watch?v=WhWc3b3KhnY', '2D', current_date - 9, 'Now Showing'),
  ('Orchard Voltage', 'Animation', 102,
   'In a grove that fruits only after midnight, a cartographer maps fruit that remembers every hand that picked it.',
   '/films/orchard-voltage.jpg', 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', '2D', current_date - 30, 'Now Showing'),
  ('Hollow Frequency', 'Horror', 128,
   'A closed concert hall keeps selling one seat. Whoever sits there hears the encore that never happened.',
   '/films/hollow-frequency.jpg', 'https://www.youtube.com/watch?v=R6MlUcmOul8', '3D', current_date + 21, 'Coming Soon'),
  ('Meridian Fall', 'Drama', 141,
   'On the last calm evening before a city changes its name, a daughter walks the cliff road her mother mapped by hand.',
   '/films/meridian-fall.jpg', 'https://www.youtube.com/watch?v=WhWc3b3KhnY', '2D', current_date + 35, 'Coming Soon')
) as v(title, genre, duration_min, description, poster_url, trailer_url, format, release_date, status)
where not exists (select 1 from movies limit 1);

-- C1: 10:00 Glass Tide, 13:00 Eclipse Meridian, 16:30 Velvet Static, 19:00 Paper Moons
insert into showtimes (movie_id, hall_id, show_date, start_time, format, ticket_price)
select m.id, 'C1', current_date + d.n, t.start_time, m.format, t.price
from generate_series(0, 4) as d(n)
join (values
  ('Glass Tide', '10:00', 1500),
  ('Eclipse Meridian', '13:00', 1800),
  ('Velvet Static', '16:30', 1500),
  ('Paper Moons', '19:00', 1500)
) as t(title, start_time, price) on true
join movies m on m.title = t.title
where not exists (select 1 from showtimes limit 1);

insert into showtimes (movie_id, hall_id, show_date, start_time, format, ticket_price)
select m.id, 'C2', current_date + d.n, t.start_time, m.format, t.price
from generate_series(0, 4) as d(n)
join (values
  ('Crown of Ash', '11:00', 1500),
  ('Orchard Voltage', '14:15', 1300),
  ('Glass Tide', '16:30', 1300),
  ('Eclipse Meridian', '19:30', 1500)
) as t(title, start_time, price) on true
join movies m on m.title = t.title
where (select count(*) from showtimes) = 20;

insert into showtimes (movie_id, hall_id, show_date, start_time, format, ticket_price)
select m.id, 'C3', current_date + d.n, t.start_time, m.format, t.price
from generate_series(0, 4) as d(n)
join (values
  ('Velvet Static', '10:30', 1300),
  ('Paper Moons', '13:00', 1300),
  ('Orchard Voltage', '15:30', 1300),
  ('Glass Tide', '18:00', 1300)
) as t(title, start_time, price) on true
join movies m on m.title = t.title
where (select count(*) from showtimes) = 40;

insert into customers (full_name, phone, email)
select * from (values
  ('Amaya Fernando', '0775550142', 'amaya.fernando@example.com'),
  ('Rohan Silva', '0715550188', 'rohan.silva@example.com'),
  ('Nila Perera', '0765550130', 'nila.perera@example.com')
) as v(full_name, phone, email)
where not exists (select 1 from customers limit 1);

insert into bookings (customer_id, showtime_id, total_amount, payment_status, booking_status, ticket_code, seat_list)
select c.id, s.id, 3000, 'Paid', 'Confirmed',
  'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100001', 'C4, C5'
from customers c
join showtimes s on s.hall_id = 'C1' and s.start_time = '10:00' and s.show_date = current_date
join movies m on m.id = s.movie_id and m.title = 'Glass Tide'
where c.email = 'amaya.fernando@example.com'
  and not exists (select 1 from bookings limit 1);

insert into booking_seats (booking_id, seat_id, showtime_id)
select b.id, st.id, b.showtime_id
from bookings b
join seats st on st.hall_id = 'C1' and st.seat_code in ('C4', 'C5')
where b.ticket_code = 'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100001';

insert into bookings (customer_id, showtime_id, total_amount, payment_status, booking_status, ticket_code, seat_list)
select c.id, s.id, 1500, 'Paid', 'Confirmed',
  'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100002', 'A1'
from customers c
join showtimes s on s.hall_id = 'C2' and s.start_time = '11:00' and s.show_date = current_date
join movies m on m.id = s.movie_id and m.title = 'Crown of Ash'
where c.email = 'rohan.silva@example.com'
  and not exists (select 1 from bookings where ticket_code like '%-100002');

insert into booking_seats (booking_id, seat_id, showtime_id)
select b.id, st.id, b.showtime_id
from bookings b
join seats st on st.hall_id = 'C2' and st.seat_code = 'A1'
where b.ticket_code = 'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100002';

insert into bookings (customer_id, showtime_id, total_amount, payment_status, booking_status, ticket_code, seat_list)
select c.id, s.id, 2600, 'Paid', 'Confirmed',
  'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100003', 'B10, B11'
from customers c
join showtimes s on s.hall_id = 'C3' and s.start_time = '13:00' and s.show_date = current_date
join movies m on m.id = s.movie_id and m.title = 'Paper Moons'
where c.email = 'nila.perera@example.com'
  and not exists (select 1 from bookings where ticket_code like '%-100003');

insert into booking_seats (booking_id, seat_id, showtime_id)
select b.id, st.id, b.showtime_id
from bookings b
join seats st on st.hall_id = 'C3' and st.seat_code in ('B10', 'B11')
where b.ticket_code = 'NEX-' || to_char(current_date, 'YYYYMMDD') || '-100003';

insert into payments (booking_id, amount, payment_method, payment_status, transaction_reference)
select b.id, b.total_amount, 'Card', 'Paid', 'TXN-' || b.id::text
from bookings b
where not exists (select 1 from payments limit 1);
