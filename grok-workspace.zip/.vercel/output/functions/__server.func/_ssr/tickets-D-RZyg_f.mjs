import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-C7TEGcdy.mjs";
import { i as GoldButton, n as Field, s as TextInput } from "./ui-BSmzlgpM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tickets-D-RZyg_f.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TicketsPage() {
	const navigate = useNavigate();
	const [code, setCode] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-gold",
				children: "TICKETS"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl",
				children: "Find a booking"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Enter the code printed on the ticket. It looks like NEX-20261008-100001."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 grid gap-4",
				onSubmit: (event) => {
					event.preventDefault();
					const next = code.trim();
					if (next) navigate({
						to: "/ticket/$code",
						params: { code: next }
					});
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Booking code",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: code,
						onChange: (event) => setCode(event.target.value),
						autoCapitalize: "characters"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
					type: "submit",
					className: "w-fit",
					children: "Open ticket"
				})]
			})
		]
	}) });
}
//#endregion
export { TicketsPage as component };
