import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as formatDuration, o as formatLkr } from "./rules-COHaUayQ.mjs";
import { n as Shell } from "./shell-C7TEGcdy.mjs";
import { a as Route$6 } from "./router-BYYkZVLE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dl9Jm7WW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MovieCard({ movie }) {
	const soon = movie.status === "Coming Soon";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/movies/$movieId",
		params: { movieId: String(movie.id) },
		className: "group block",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "overflow-hidden rounded-2xl border border-line bg-surface",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative aspect-[2/3] overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: movie.poster_url,
					alt: "",
					className: "h-full w-full object-cover transition-transform duration-200 group-hover:scale-[1.03]"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 bg-bg/80 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-none text-cream",
						children: movie.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs tracking-wide text-muted",
						children: [
							movie.genre,
							" · ",
							formatDuration(movie.duration_min),
							" · ",
							movie.format
						]
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-3 py-3 text-sm text-gold",
				children: soon ? "Coming soon" : "Book a seat"
			})]
		})
	});
}
function matches(movie, query, genre, format) {
	const q = query.trim().toLowerCase();
	if (q && !`${movie.title} ${movie.genre}`.toLowerCase().includes(q)) return false;
	if (genre !== "All" && movie.genre !== genre) return false;
	if (format !== "All" && movie.format !== format) return false;
	return true;
}
function Home() {
	const { movies, halls } = Route$6.useLoaderData();
	const [query, setQuery] = (0, import_react.useState)("");
	const [genre, setGenre] = (0, import_react.useState)("All");
	const [format, setFormat] = (0, import_react.useState)("All");
	const genres = (0, import_react.useMemo)(() => ["All", ...new Set(movies.map((movie) => movie.genre))], [movies]);
	const showing = movies.filter((movie) => movie.status === "Now Showing" && matches(movie, query, genre, format));
	const soon = movies.filter((movie) => movie.status === "Coming Soon" && matches(movie, query, genre, format));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-h-[78vh] overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/films/hero.jpg",
					alt: "",
					className: "absolute inset-0 h-full w-full object-cover",
					fetchPriority: "high"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-bg/75" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto flex min-h-[78vh] max-w-6xl flex-col justify-end px-4 py-16 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-gold",
							children: "NEXORA DOLBY CINEMA"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 max-w-3xl font-display text-6xl leading-none text-cream sm:text-7xl",
							children: "Where stories become worlds."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-lg text-cream",
							children: "Three houses under one roof. Dolby Atmos and 8K laser in C1. A seat is held for one screening, never for the hall."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#now",
							className: "mt-8 inline-flex min-h-11 w-fit items-center rounded-full bg-gold px-5 font-medium text-bg",
							children: "See what is on"
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-4 py-12 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Search the programme",
						"aria-label": "Search the programme",
						className: "min-h-11 rounded-lg border border-line bg-surface px-3 text-cream placeholder:text-muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: genre,
						onChange: (event) => setGenre(event.target.value),
						"aria-label": "Filter by genre",
						className: "min-h-11 rounded-lg border border-line bg-surface px-3 text-cream",
						children: genres.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: format,
						onChange: (event) => setFormat(event.target.value),
						"aria-label": "Filter by format",
						className: "min-h-11 rounded-lg border border-line bg-surface px-3 text-cream",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "All" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "2D" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "3D" })
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "now",
			className: "mx-auto max-w-6xl scroll-mt-24 px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-5xl",
				children: "Now showing"
			}), showing.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-muted",
				children: "Nothing on the board matches that."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid grid-cols-2 gap-4 lg:grid-cols-3",
				children: showing.map((movie) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MovieCard, { movie }, movie.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "soon",
			className: "mx-auto mt-16 max-w-6xl scroll-mt-24 px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-5xl",
					children: "Coming soon"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "These are not open for seats yet."
				}),
				soon.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-muted",
					children: "No coming titles match that search."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid grid-cols-2 gap-4 lg:grid-cols-3",
					children: soon.map((movie) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MovieCard, { movie }, movie.id))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "halls",
			className: "mx-auto mt-20 max-w-6xl scroll-mt-24 px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-5xl",
				children: "The houses"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 md:grid-cols-3",
				children: halls.map((hall) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-gold",
							children: hall.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-display text-3xl",
							children: hall.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: hall.tagline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: hall.projection }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: hall.sound }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [hall.capacity, " seats · rows A to G"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["2D ", formatLkr(hall.price_2d)] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: hall.price_3d == null ? "3D not available" : `3D ${formatLkr(hall.price_3d)}` })
							]
						})
					]
				}, hall.id))
			})]
		})
	] });
}
//#endregion
export { Home as component };
