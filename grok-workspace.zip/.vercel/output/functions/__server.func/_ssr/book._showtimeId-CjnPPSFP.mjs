import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as formatDay, o as formatLkr, r as formatClock, s as luhn, u as sortSeatCodes } from "./rules-COHaUayQ.mjs";
import { n as Shell } from "./shell-C7TEGcdy.mjs";
import { i as Route$2, o as createBooking } from "./router-BYYkZVLE.mjs";
import { a as Note, i as GoldButton, n as Field, r as GhostButton, s as TextInput } from "./ui-BSmzlgpM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book._showtimeId-CjnPPSFP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookPage() {
	const data = Route$2.useLoaderData();
	const seats = data?.seats ?? [];
	const rows = (0, import_react.useMemo)(() => {
		const grouped = /* @__PURE__ */ new Map();
		for (const seat of seats) {
			const list = grouped.get(seat.row_label) ?? [];
			list.push(seat);
			grouped.set(seat.row_label, list);
		}
		return [...grouped.entries()];
	}, [seats]);
	const router = useRouter();
	const navigate = Route$2.useNavigate();
	const [step, setStep] = (0, import_react.useState)("seats");
	const [picked, setPicked] = (0, import_react.useState)([]);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [card, setCard] = (0, import_react.useState)("");
	const [holder, setHolder] = (0, import_react.useState)("");
	const [expiry, setExpiry] = (0, import_react.useState)("");
	const [cvv, setCvv] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-6 py-24 text-muted",
		children: "That screening has left the board."
	}) });
	const { movie, showtime } = data;
	const selected = seats.filter((seat) => picked.includes(seat.id) && seat.status === "available");
	const total = selected.length * showtime.ticket_price;
	function toggle(seat) {
		if (seat.status === "booked") return;
		if (!picked.includes(seat.id) && picked.length >= 10) {
			setError("Ten seats is the house limit for one ticket.");
			return;
		}
		setError("");
		setPicked((current) => current.includes(seat.id) ? current.filter((id) => id !== seat.id) : [...current, seat.id]);
	}
	function validateGuest() {
		if (name.trim().length < 2) return "Enter the name on the ticket.";
		const digits = phone.replace(/\D/g, "");
		if (digits.length < 9 || digits.length > 15) return "Enter a phone number we can read back.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return "Enter a valid email.";
		return "";
	}
	function validateCard() {
		const digits = card.replace(/\D/g, "");
		if (digits.length < 13 || digits.length > 19 || !luhn(digits)) return "That card number does not check out.";
		if (holder.trim().length < 2) return "Enter the name on the card.";
		const match = expiry.trim().match(/^(\d{2})\s*\/\s*(\d{2})$/);
		if (!match) return "Use an expiry like 12/28.";
		const month = Number(match[1]);
		const year = 2e3 + Number(match[2]);
		if (month < 1 || month > 12) return "That expiry month is not real.";
		const now = /* @__PURE__ */ new Date();
		if (year < now.getFullYear() || year === now.getFullYear() && month < now.getMonth() + 1) return "That card is already expired.";
		if (!/^\d{3,4}$/.test(cvv.trim())) return "Enter the CVV. It is not stored.";
		return "";
	}
	async function pay() {
		const problem = validateCard();
		if (problem) {
			setError(problem);
			return;
		}
		setBusy(true);
		setError("");
		try {
			const result = await createBooking({ data: {
				showtimeId: showtime.id,
				seatIds: selected.map((seat) => seat.id),
				fullName: name.trim(),
				phone: phone.trim(),
				email: email.trim()
			} });
			await navigate({
				to: "/ticket/$code",
				params: { code: result.ticketCode }
			});
		} catch (err) {
			setError(err instanceof Error ? err.message : "The booking did not go through.");
			await router.invalidate();
			setPicked([]);
			setStep("seats");
		} finally {
			setBusy(false);
		}
	}
	const codes = sortSeatCodes(selected.map((seat) => seat.seat_code));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[1fr_20rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs tracking-widest text-gold",
				children: [
					showtime.hall_id,
					" · ",
					showtime.format
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl",
				children: movie.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-muted",
				children: [
					formatDay(showtime.show_date),
					" · ",
					formatClock(showtime.start_time),
					" · ",
					showtime.hall_name
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					showtime.projection,
					" · ",
					showtime.sound
				]
			}),
			step === "seats" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 rounded-full border border-line py-2 text-center text-xs tracking-widest text-gold",
						children: "SCREEN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto pb-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-max space-y-2",
							children: rows.map(([label, row]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-5 text-sm text-muted",
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex gap-1",
									children: row.map((seat, index) => {
										const on = selected.some((item) => item.id === seat.id);
										const booked = seat.status === "booked";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: booked,
											"aria-pressed": on,
											"aria-label": `Seat ${seat.seat_code}, ${booked ? "booked" : on ? "selected" : "available"}`,
											onClick: () => toggle(seat),
											className: `size-11 rounded-sm text-xs tabular-nums ${booked ? "bg-alert text-cream" : on ? "bg-cream text-bg" : "bg-open text-cream"} ${index === 9 ? "ml-4" : ""}`,
											children: seat.seat_number
										}, seat.id);
									})
								})]
							}, label))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-3 rounded-sm bg-open" }), " Open"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-3 rounded-sm bg-alert" }), " Booked"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-3 rounded-sm bg-cream" }), " Selected"]
							})
						]
					})
				]
			}) : null,
			step === "details" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 grid max-w-md gap-4",
				onSubmit: (event) => {
					event.preventDefault();
					const problem = validateGuest();
					if (problem) setError(problem);
					else {
						setError("");
						setStep("pay");
					}
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Full name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: name,
							onChange: (event) => setName(event.target.value),
							autoComplete: "name"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: phone,
							onChange: (event) => setPhone(event.target.value),
							autoComplete: "tel",
							inputMode: "tel"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: email,
							onChange: (event) => setEmail(event.target.value),
							autoComplete: "email",
							inputMode: "email"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							type: "button",
							onClick: () => setStep("seats"),
							children: "Back"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
							type: "submit",
							children: "Continue"
						})]
					})
				]
			}) : null,
			step === "pay" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 grid max-w-md gap-4",
				onSubmit: (event) => {
					event.preventDefault();
					pay();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-surface-2 p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-gold",
								children: "CARD"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 font-display text-3xl tabular-nums",
								children: card || "•••• •••• •••• ••••"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-sm",
								children: [
									holder || "Name on card",
									" · ",
									expiry || "MM/YY"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Card number",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: card,
							onChange: (event) => setCard(event.target.value),
							inputMode: "numeric",
							autoComplete: "off",
							placeholder: "4242 4242 4242 4242"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Card holder",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: holder,
							onChange: (event) => setHolder(event.target.value),
							autoComplete: "off"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Expiry",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								value: expiry,
								onChange: (event) => setExpiry(event.target.value),
								placeholder: "12/28",
								autoComplete: "off"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "CVV",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								value: cvv,
								onChange: (event) => setCvv(event.target.value),
								inputMode: "numeric",
								autoComplete: "off",
								placeholder: "123"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Demonstration only. Try 4242 4242 4242 4242, any future expiry, any CVV. The card is not stored and nothing is charged."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							type: "button",
							onClick: () => setStep("details"),
							children: "Back"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
							type: "submit",
							disabled: busy,
							children: busy ? "Taking payment…" : `Pay ${formatLkr(total)}`
						})]
					})
				]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: error }) : null
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "h-fit rounded-2xl border border-line bg-surface p-5 lg:sticky lg:top-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-gold",
					children: "THIS TICKET"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-display text-3xl",
					children: movie.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						formatDay(showtime.show_date),
						" · ",
						formatClock(showtime.start_time)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						showtime.hall_id,
						" · ",
						showtime.format,
						" · ",
						formatLkr(showtime.ticket_price),
						" each"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm",
					children: "Seats"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg",
					children: codes.length ? codes.join(", ") : "None yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-muted",
					children: [
						selected.length,
						" ",
						selected.length === 1 ? "ticket" : "tickets"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl tabular-nums",
					children: formatLkr(total)
				}),
				step === "seats" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
					className: "mt-5 w-full",
					disabled: selected.length === 0 || movie.status !== "Now Showing",
					onClick: () => {
						setError("");
						setStep("details");
					},
					children: "Continue"
				}) : null
			]
		})]
	}) });
}
//#endregion
export { BookPage as component };
