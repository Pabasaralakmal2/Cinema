import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/cinema/shell";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
});

const facts = [
  ["Address", "12 Galle Face Terrace, Colombo 03"],
  ["Phone", "+94 11 555 0190"],
  ["Email", "hello@nexora.cinema"],
  ["Hours", "Open daily, 9:30 AM – 11:30 PM"],
];

function ContactPage() {
  return (
    <Shell>
      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2">
        <div>
          <p className="text-xs tracking-widest text-gold">CONTACT</p>
          <h1 className="mt-2 font-display text-6xl leading-none">Nexora Dolby Cinema</h1>
          <p className="mt-4 font-display text-3xl text-cream">Where stories become worlds.</p>
          <p className="mt-4 max-w-md text-muted">
            The box office answers for tickets, school visits, and private hires. This address belongs to the project, not a real theatre.
          </p>
        </div>
        <dl className="grid gap-4">
          {facts.map(([label, value]) => (
            <div key={label} className="rounded-2xl border border-line bg-surface p-5">
              <dt className="text-xs tracking-widest text-gold">{label.toUpperCase()}</dt>
              <dd className="mt-2 text-lg">{value}</dd>
            </div>
          ))}
        </dl>
      </section>
    </Shell>
  );
}
