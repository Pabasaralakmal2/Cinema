import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { c as priceFor, l as rangesOverlap, n as clockToMinutes } from "./rules-COHaUayQ.mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-CPhNTB41.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var CinemaError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "CinemaError";
	}
};
function parse(schema, input) {
	const res = schema.safeParse(input);
	if (!res.success) throw new CinemaError(res.error.issues[0]?.message ?? "Check the form and try again.");
	return res.data;
}
function assertHouse(code) {
	if (code.trim().toUpperCase() !== "NEXORA") throw new CinemaError("That house code is not recognised.");
}
function asFormat(value) {
	return value === "3D" ? "3D" : "2D";
}
function asStatus(value) {
	return value === "Coming Soon" ? "Coming Soon" : "Now Showing";
}
function day(value) {
	return String(value).slice(0, 10);
}
function flag(value) {
	return value === true || value === "t" || value === 1 || value === "true";
}
function num(value) {
	return Number(value);
}
async function db(fn) {
	try {
		const { getSql } = await import("./db-CNQMjRIS.mjs");
		return await fn(await getSql());
	} catch (err) {
		if (err instanceof CinemaError) throw err;
		const code = err.code;
		const message = err instanceof Error ? err.message : "";
		if (code === "23505" || /duplicate key|unique/i.test(message)) throw new CinemaError("That clashes with a seat, screening, or ticket already saved.");
		if (code === "23503" || /foreign key/i.test(message)) throw new CinemaError("That record is still tied to a booking or a screening.");
		console.error(err);
		throw new CinemaError("The cinema database could not complete that. Try again.");
	}
}
function mapMovie(row) {
	return {
		id: num(row.id),
		title: String(row.title),
		genre: String(row.genre),
		duration_min: num(row.duration_min),
		description: String(row.description),
		poster_url: String(row.poster_url),
		trailer_url: String(row.trailer_url),
		format: asFormat(String(row.format)),
		release_date: day(row.release_date),
		status: asStatus(String(row.status))
	};
}
function mapHall(row) {
	return {
		id: String(row.id),
		name: String(row.name),
		tagline: String(row.tagline),
		projection: String(row.projection),
		sound: String(row.sound),
		supports_3d: flag(row.supports_3d),
		capacity: num(row.capacity),
		price_2d: num(row.price_2d),
		price_3d: row.price_3d == null ? null : num(row.price_3d)
	};
}
var MOVIE_SQL = `select id, title, genre, duration_min, description, poster_url, trailer_url, format, release_date, status from movies`;
async function loadMovies(sql) {
	return (await sql.query(`${MOVIE_SQL} order by case when status = 'Now Showing' then 0 else 1 end, title`)).map(mapMovie);
}
async function loadHalls(sql) {
	return (await sql.query(`select id, name, tagline, projection, sound, supports_3d, capacity, price_2d, price_3d from halls order by id`)).map(mapHall);
}
async function today(sql) {
	return (await sql.query(`select current_date::text as today`))[0]?.today ?? "1970-01-01";
}
async function assertNoOverlap(sql, hallId, showDate, startTime, durationMin, ignoreId) {
	const rows = await sql.query(`select s.id, s.start_time, m.duration_min
     from showtimes s
     join movies m on m.id = s.movie_id
     where s.hall_id = $1 and s.show_date = $2 and ($3::int is null or s.id <> $3)`, [
		hallId,
		showDate,
		ignoreId ?? null
	]);
	const start = clockToMinutes(startTime);
	for (const row of rows) if (rangesOverlap(start, durationMin, clockToMinutes(row.start_time), num(row.duration_min))) throw new CinemaError(`That screening overlaps another film in ${hallId}. Leave a gap after the runtime.`);
}
var movieSchema = object({
	id: number().int().positive().optional(),
	title: string().trim().min(1, "Give the film a title.").max(120),
	genre: string().trim().min(2, "Add a genre.").max(40),
	durationMin: number().int().min(45, "Runtime looks too short.").max(300, "Runtime looks too long."),
	description: string().trim().min(10, "Add a short description.").max(800),
	posterUrl: string().trim().min(1, "Add a poster address.").max(400),
	trailerUrl: string().trim().url("Trailer needs a full web address.").max(400),
	format: _enum(["2D", "3D"]),
	releaseDate: string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use a real release date."),
	status: _enum(["Now Showing", "Coming Soon"])
});
var showSchema = object({
	id: number().int().positive().optional(),
	movieId: number().int().positive(),
	hallId: string().trim().min(1),
	showDate: string().regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a date."),
	startTime: string().regex(/^([01]\d|2[0-3]):[0-5]\d/, "Choose a start time.")
});
var personSchema = object({
	fullName: string().trim().min(2, "Enter the name on the ticket.").max(80),
	phone: string().trim().refine((value) => value.replace(/\D/g, "").length >= 9 && value.replace(/\D/g, "").length <= 15, { message: "Enter a phone number we can read back." }),
	email: string().trim().email("Enter a valid email.").max(120)
});
var getHome_createServerFn_handler = createServerRpc({
	id: "8fa606defa0a5ff4be69b37a17276f3d746c53a9a4544613844ec0b2a35ff353",
	name: "getHome",
	filename: "src/lib/cinema/api.ts"
}, (opts) => getHome.__executeServer(opts));
var getHome = createServerFn({ method: "GET" }).handler(getHome_createServerFn_handler, async () => {
	return db(async (sql) => {
		const [movies, halls] = await Promise.all([loadMovies(sql), loadHalls(sql)]);
		return {
			movies,
			halls
		};
	});
});
var getMovie_createServerFn_handler = createServerRpc({
	id: "f3e67719a4b3072f3dbaeb98c9ada7c2e6ec668538c1b769aed44ce2cd77e66b",
	name: "getMovie",
	filename: "src/lib/cinema/api.ts"
}, (opts) => getMovie.__executeServer(opts));
var getMovie = createServerFn({ method: "GET" }).validator((input) => parse(object({ id: number().int().positive() }), input)).handler(getMovie_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		const rows = await sql.query(`${MOVIE_SQL} where id = $1`, [data.id]);
		const movie = rows[0] ? mapMovie(rows[0]) : null;
		if (!movie) return null;
		return {
			movie,
			showtimes: (await sql.query(`select s.id, s.movie_id, s.hall_id, s.show_date, s.start_time, s.format, s.ticket_price,
                h.name as hall_name, h.projection, h.sound
         from showtimes s
         join halls h on h.id = s.hall_id
         where s.movie_id = $1 and s.show_date >= current_date
         order by s.show_date, s.start_time, s.hall_id`, [data.id])).map((row) => ({
				id: num(row.id),
				movie_id: num(row.movie_id),
				hall_id: String(row.hall_id),
				show_date: day(row.show_date),
				start_time: String(row.start_time).slice(0, 5),
				format: asFormat(String(row.format)),
				ticket_price: num(row.ticket_price),
				hall_name: String(row.hall_name),
				projection: String(row.projection),
				sound: String(row.sound)
			}))
		};
	});
});
var getShowtime_createServerFn_handler = createServerRpc({
	id: "6ae68061f5ed49dea0e3c79dc369f865823e4c1b0ff7f5b8433a63c811ad10af",
	name: "getShowtime",
	filename: "src/lib/cinema/api.ts"
}, (opts) => getShowtime.__executeServer(opts));
var getShowtime = createServerFn({ method: "GET" }).validator((input) => parse(object({ id: number().int().positive() }), input)).handler(getShowtime_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => loadShow(sql, data.id));
});
async function loadShow(sql, id) {
	const row = (await sql.query(`select s.id, s.movie_id, s.hall_id, s.show_date, s.start_time, s.format, s.ticket_price,
            h.name as hall_name, h.projection, h.sound,
            m.title, m.genre, m.duration_min, m.description, m.poster_url, m.trailer_url,
            m.format as movie_format, m.release_date, m.status
     from showtimes s
     join halls h on h.id = s.hall_id
     join movies m on m.id = s.movie_id
     where s.id = $1`, [id]))[0];
	if (!row) return null;
	const movie = mapMovie({
		id: row.movie_id,
		title: row.title,
		genre: row.genre,
		duration_min: row.duration_min,
		description: row.description,
		poster_url: row.poster_url,
		trailer_url: row.trailer_url,
		format: row.movie_format,
		release_date: row.release_date,
		status: row.status
	});
	const showtime = {
		id: num(row.id),
		movie_id: movie.id,
		hall_id: String(row.hall_id),
		show_date: day(row.show_date),
		start_time: String(row.start_time).slice(0, 5),
		format: asFormat(String(row.format)),
		ticket_price: num(row.ticket_price),
		hall_name: String(row.hall_name),
		projection: String(row.projection),
		sound: String(row.sound),
		movie_title: movie.title,
		duration_min: movie.duration_min
	};
	return {
		movie,
		showtime,
		seats: (await sql.query(`select st.id, st.row_label, st.seat_number, st.seat_code,
            case when bs.id is null then 'available' else 'booked' end as status
     from seats st
     left join booking_seats bs on bs.seat_id = st.id and bs.showtime_id = $1
     where st.hall_id = $2
     order by st.row_label, st.seat_number`, [id, showtime.hall_id])).map((seat) => ({
			id: num(seat.id),
			row_label: String(seat.row_label),
			seat_number: num(seat.seat_number),
			seat_code: String(seat.seat_code),
			status: seat.status === "booked" ? "booked" : "available"
		}))
	};
}
var bookSchema = personSchema.extend({
	showtimeId: number().int().positive(),
	seatIds: array(number().int().positive()).min(1, "Choose at least one seat.").max(10, "Ten seats is the house limit.")
});
var createBooking_createServerFn_handler = createServerRpc({
	id: "33210d0c3e4b68a72c8b1b002cc33609535f4f57cdf50cf56cfeeefc8aa0ca25",
	name: "createBooking",
	filename: "src/lib/cinema/api.ts"
}, (opts) => createBooking.__executeServer(opts));
var createBooking = createServerFn({ method: "POST" }).validator((input) => parse(bookSchema, input)).handler(createBooking_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		const seatCsv = [...new Set(data.seatIds)].join(",");
		const show = await loadShow(sql, data.showtimeId);
		if (!show) throw new CinemaError("That screening is no longer on the board.");
		if (show.movie.status !== "Now Showing") throw new CinemaError("This film is not open for booking yet.");
		const chosen = show.seats.filter((seat) => data.seatIds.includes(seat.id));
		if (chosen.length !== new Set(data.seatIds).size) throw new CinemaError("One of those seats is not in this hall.");
		const taken = chosen.filter((seat) => seat.status === "booked");
		if (taken.length) throw new CinemaError(`Already booked: ${taken.map((seat) => seat.seat_code).join(", ")}.`);
		const code = ticketCode(show.showtime.show_date);
		const txn = `TXN-${Math.floor(1e6 + Math.random() * 9e6)}`;
		const rows = await sql.query(`with show as (
           select s.id, s.ticket_price, m.status
           from showtimes s join movies m on m.id = s.movie_id
           where s.id = $1
         ),
         seat_input as (
           select distinct val::int as seat_id
           from unnest(string_to_array($2, ',')) as t(val)
           where val <> ''
         ),
         gate as (
           select (
             (select count(*) from show) = 1
             and (select status from show) = 'Now Showing'
             and (select count(*) from seat_input) = $3
             and (select count(*) from seats st
                  join seat_input si on si.seat_id = st.id
                  where st.hall_id = (select hall_id from showtimes where id = $1)) = $3
             and not exists (
               select 1 from booking_seats bs
               join seat_input si on si.seat_id = bs.seat_id
               where bs.showtime_id = $1
             )
           ) as ok
         ),
         cust as (
           insert into customers (full_name, phone, email)
           select $4, $5, $6 from gate where ok
           returning id
         ),
         bk as (
           insert into bookings (customer_id, showtime_id, total_amount, payment_status, booking_status, ticket_code, seat_list)
           select cust.id, show.id, show.ticket_price * $3, 'Paid', 'Confirmed', $7,
             (select string_agg(st.seat_code, ', ' order by st.row_label, st.seat_number)
              from seats st join seat_input si on si.seat_id = st.id)
           from cust, show
           returning id, ticket_code, showtime_id, total_amount
         ),
         bs as (
           insert into booking_seats (booking_id, seat_id, showtime_id)
           select bk.id, si.seat_id, bk.showtime_id
           from bk cross join seat_input si
           returning seat_id
         ),
         pay as (
           insert into payments (booking_id, amount, payment_method, payment_status, transaction_reference)
           select bk.id, bk.total_amount, 'Card', 'Paid', $8 from bk
           returning id
         )
         select ticket_code from bk`, [
			data.showtimeId,
			seatCsv,
			chosen.length,
			data.fullName,
			data.phone,
			data.email,
			code,
			txn
		]);
		if (!rows[0]) throw new CinemaError("Those seats were just booked. Choose again.");
		return { ticketCode: rows[0].ticket_code };
	});
});
function ticketCode(date) {
	return `NEX-${date.replaceAll("-", "")}-${Math.floor(1e5 + Math.random() * 9e5)}`;
}
async function loadTicket(sql, code) {
	const row = (await sql.query(`select b.ticket_code, b.total_amount, b.payment_status, b.booking_status, b.seat_list,
            c.full_name, m.title, s.show_date, s.start_time, s.hall_id, s.format,
            h.name as hall_name, h.projection, h.sound
     from bookings b
     join customers c on c.id = b.customer_id
     join showtimes s on s.id = b.showtime_id
     join movies m on m.id = s.movie_id
     join halls h on h.id = s.hall_id
     where upper(b.ticket_code) = upper($1)`, [code.trim()]))[0];
	if (!row) return null;
	const bookingStatus = String(row.booking_status);
	const paymentStatus = String(row.payment_status);
	return {
		ticket_code: String(row.ticket_code),
		full_name: String(row.full_name),
		title: String(row.title),
		show_date: day(row.show_date),
		start_time: String(row.start_time).slice(0, 5),
		hall_id: String(row.hall_id),
		hall_name: String(row.hall_name),
		projection: String(row.projection),
		sound: String(row.sound),
		format: asFormat(String(row.format)),
		seats: String(row.seat_list),
		total_amount: num(row.total_amount),
		payment_status: paymentStatus,
		booking_status: bookingStatus,
		verdict: bookingStatus === "Confirmed" && paymentStatus === "Paid" ? "valid" : "invalid"
	};
}
var getTicket_createServerFn_handler = createServerRpc({
	id: "3718de972080aac40311675977e7199534f3b91706ec3844a6486b59409f5228",
	name: "getTicket",
	filename: "src/lib/cinema/api.ts"
}, (opts) => getTicket.__executeServer(opts));
var getTicket = createServerFn({ method: "GET" }).validator((input) => parse(object({ code: string().trim().min(4).max(40) }), input)).handler(getTicket_createServerFn_handler, async ({ data }) => db(async (sql) => loadTicket(sql, data.code)));
var houseSchema = object({ code: string().min(1, "Enter the house code.") });
async function statsOf(sql) {
	const row = (await sql.query(`select
       (select count(*) from movies) as movies,
       (select count(*) from movies where status = 'Now Showing') as now_showing,
       (select count(*) from movies where status = 'Coming Soon') as coming_soon,
       (select count(*) from bookings where booking_status <> 'Cancelled') as bookings,
       (select count(*) from showtimes where show_date = current_date) as today,
       (select count(*) from customers) as customers`))[0] ?? {};
	return {
		movies: num(row.movies),
		now_showing: num(row.now_showing),
		coming_soon: num(row.coming_soon),
		bookings: num(row.bookings),
		today: num(row.today),
		customers: num(row.customers)
	};
}
async function loadBookings(sql) {
	return (await sql.query(`select b.id, b.ticket_code, b.total_amount, b.payment_status, b.booking_status, b.seat_list,
            c.full_name, c.phone, c.email, c.id as customer_id,
            m.title as movie_title, s.hall_id, s.show_date, s.start_time, s.format
     from bookings b
     join customers c on c.id = b.customer_id
     join showtimes s on s.id = b.showtime_id
     join movies m on m.id = s.movie_id
     order by b.id desc`)).map((row) => ({
		id: num(row.id),
		ticket_code: String(row.ticket_code),
		total_amount: num(row.total_amount),
		payment_status: String(row.payment_status),
		booking_status: String(row.booking_status),
		seat_list: String(row.seat_list),
		full_name: String(row.full_name),
		phone: String(row.phone),
		email: String(row.email),
		customer_id: num(row.customer_id),
		movie_title: String(row.movie_title),
		hall_id: String(row.hall_id),
		show_date: day(row.show_date),
		start_time: String(row.start_time).slice(0, 5),
		format: asFormat(String(row.format))
	}));
}
async function loadCustomers(sql) {
	return (await sql.query(`select c.id, c.full_name, c.phone, c.email, count(b.id) as bookings
     from customers c
     left join bookings b on b.customer_id = c.id
     group by c.id
     order by c.full_name`)).map((row) => ({
		id: num(row.id),
		full_name: String(row.full_name),
		phone: String(row.phone),
		email: String(row.email),
		bookings: num(row.bookings)
	}));
}
async function loadBoard(sql) {
	return (await sql.query(`select s.id, s.movie_id, s.hall_id, s.show_date, s.start_time, s.format, s.ticket_price,
            h.name as hall_name, h.projection, h.sound, m.title as movie_title, m.duration_min
     from showtimes s
     join halls h on h.id = s.hall_id
     join movies m on m.id = s.movie_id
     where s.show_date >= current_date
     order by s.show_date, s.start_time, s.hall_id`)).map((row) => ({
		id: num(row.id),
		movie_id: num(row.movie_id),
		hall_id: String(row.hall_id),
		show_date: day(row.show_date),
		start_time: String(row.start_time).slice(0, 5),
		format: asFormat(String(row.format)),
		ticket_price: num(row.ticket_price),
		hall_name: String(row.hall_name),
		projection: String(row.projection),
		sound: String(row.sound),
		movie_title: String(row.movie_title),
		duration_min: num(row.duration_min)
	}));
}
async function bundle(sql) {
	const [stats, movies, halls, showtimes, bookings, customers] = await Promise.all([
		statsOf(sql),
		loadMovies(sql),
		loadHalls(sql),
		loadBoard(sql),
		loadBookings(sql),
		loadCustomers(sql)
	]);
	return {
		stats,
		movies,
		halls,
		showtimes,
		bookings,
		customers
	};
}
var staffDesk_createServerFn_handler = createServerRpc({
	id: "09eb8761f5cfe1fe797c0167b179a303003ced8e7359a6d04c37b2dd05189937",
	name: "staffDesk",
	filename: "src/lib/cinema/api.ts"
}, (opts) => staffDesk.__executeServer(opts));
var staffDesk = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema, input)).handler(staffDesk_createServerFn_handler, async ({ data }) => db(async (sql) => {
	assertHouse(data.code);
	return bundle(sql);
}));
var saveMovie_createServerFn_handler = createServerRpc({
	id: "b7fdbac884d8fdf0c8b6a925bf93ec1fde6f89987d9f49fe6c24d8bd6efb1bc5",
	name: "saveMovie",
	filename: "src/lib/cinema/api.ts"
}, (opts) => saveMovie.__executeServer(opts));
var saveMovie = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ movie: movieSchema }), input)).handler(saveMovie_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		assertHouse(data.code);
		const movie = data.movie;
		if (movie.id) {
			const existing = await sql.query(`${MOVIE_SQL} where id = $1`, [movie.id]);
			if (!existing[0]) throw new CinemaError("That film is no longer on file.");
			const previous = mapMovie(existing[0]);
			if (movie.durationMin !== previous.duration_min || movie.format !== previous.format) {
				const shows = await sql.query(`select id, hall_id, show_date::text as show_date, start_time from showtimes where movie_id = $1`, [movie.id]);
				if (movie.format !== previous.format) {
					if (num((await sql.query(`select count(*) as n from bookings b
               join showtimes s on s.id = b.showtime_id
               where s.movie_id = $1 and b.booking_status <> 'Cancelled'`, [movie.id]))[0]?.n) > 0) throw new CinemaError("Booked screenings still use the old format. Cancel them before changing 2D or 3D.");
					for (const show of shows) if (priceFor(show.hall_id, movie.format) == null) throw new CinemaError("C3 cannot screen 3D. Move those screenings before changing the format.");
				}
				for (const show of shows) await assertNoOverlap(sql, show.hall_id, day(show.show_date), String(show.start_time).slice(0, 5), movie.durationMin, show.id);
			}
			await sql.query(`update movies set title = $1, genre = $2, duration_min = $3, description = $4, poster_url = $5,
             trailer_url = $6, format = $7, release_date = $8, status = $9 where id = $10`, [
				movie.title,
				movie.genre,
				movie.durationMin,
				movie.description,
				movie.posterUrl,
				movie.trailerUrl,
				movie.format,
				movie.releaseDate,
				movie.status,
				movie.id
			]);
			if (movie.format !== previous.format) {
				const shows = await sql.query(`select id, hall_id from showtimes where movie_id = $1`, [movie.id]);
				for (const show of shows) {
					const price = priceFor(show.hall_id, movie.format);
					if (price == null) continue;
					await sql.query(`update showtimes set format = $1, ticket_price = $2 where id = $3`, [
						movie.format,
						price,
						show.id
					]);
				}
			}
		} else await sql.query(`insert into movies (title, genre, duration_min, description, poster_url, trailer_url, format, release_date, status)
           values ($1,$2,$3,$4,$5,$6,$7,$8,$9)`, [
			movie.title,
			movie.genre,
			movie.durationMin,
			movie.description,
			movie.posterUrl,
			movie.trailerUrl,
			movie.format,
			movie.releaseDate,
			movie.status
		]);
		return bundle(sql);
	});
});
var deleteMovie_createServerFn_handler = createServerRpc({
	id: "a4a91ffcd5e7eab9c452a5359a8caadb883136c4cbcf35affb249c37a9c3502c",
	name: "deleteMovie",
	filename: "src/lib/cinema/api.ts"
}, (opts) => deleteMovie.__executeServer(opts));
var deleteMovie = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ id: number().int().positive() }), input)).handler(deleteMovie_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		assertHouse(data.code);
		if (num((await sql.query(`select count(*) as n from bookings b join showtimes s on s.id = b.showtime_id where s.movie_id = $1`, [data.id]))[0]?.n) > 0) throw new CinemaError("This film already has bookings. Cancel them before deleting it.");
		await sql.query(`delete from showtimes where movie_id = $1`, [data.id]);
		await sql.query(`delete from movies where id = $1`, [data.id]);
		return bundle(sql);
	});
});
var saveShowtime_createServerFn_handler = createServerRpc({
	id: "7f598179fc3466f3d21d050f208c97ec91d33541349663e7b75726be7991d105",
	name: "saveShowtime",
	filename: "src/lib/cinema/api.ts"
}, (opts) => saveShowtime.__executeServer(opts));
var saveShowtime = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ show: showSchema }), input)).handler(saveShowtime_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		assertHouse(data.code);
		const show = data.show;
		const start = show.startTime.slice(0, 5);
		const movies = await sql.query(`${MOVIE_SQL} where id = $1`, [show.movieId]);
		if (!movies[0]) throw new CinemaError("Choose a film that is still on file.");
		const movie = mapMovie(movies[0]);
		if (movie.status !== "Now Showing") throw new CinemaError("Coming Soon films are not open for screenings yet.");
		const price = priceFor(show.hallId, movie.format);
		if (price == null) throw new CinemaError("C3 cannot screen 3D. Choose C1 or C2.");
		if (!(await sql.query(`select id from halls where id = $1`, [show.hallId]))[0]) throw new CinemaError("That hall is not in the house.");
		const current = await today(sql);
		if (show.showDate < current) throw new CinemaError("Choose today or a future date.");
		if (show.id) {
			if (num((await sql.query(`select count(*) as n from bookings where showtime_id = $1`, [show.id]))[0]?.n) > 0) throw new CinemaError("This screening has booking history, so its time and hall stay as they are.");
		}
		await assertNoOverlap(sql, show.hallId, show.showDate, start, movie.duration_min, show.id);
		if (show.id) await sql.query(`update showtimes set movie_id = $1, hall_id = $2, show_date = $3, start_time = $4, format = $5, ticket_price = $6 where id = $7`, [
			movie.id,
			show.hallId,
			show.showDate,
			start,
			movie.format,
			price,
			show.id
		]);
		else await sql.query(`insert into showtimes (movie_id, hall_id, show_date, start_time, format, ticket_price)
           values ($1,$2,$3,$4,$5,$6)`, [
			movie.id,
			show.hallId,
			show.showDate,
			start,
			movie.format,
			price
		]);
		return bundle(sql);
	});
});
var deleteShowtime_createServerFn_handler = createServerRpc({
	id: "c43b15a9e0326f63a83b9927dc13a10f984620e9b71cdb0e3d4d2a534d034276",
	name: "deleteShowtime",
	filename: "src/lib/cinema/api.ts"
}, (opts) => deleteShowtime.__executeServer(opts));
var deleteShowtime = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ id: number().int().positive() }), input)).handler(deleteShowtime_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		assertHouse(data.code);
		if (num((await sql.query(`select count(*) as n from bookings where showtime_id = $1`, [data.id]))[0]?.n) > 0) throw new CinemaError("This screening has booking history, so it stays on record.");
		await sql.query(`delete from showtimes where id = $1`, [data.id]);
		return bundle(sql);
	});
});
var updateCustomer_createServerFn_handler = createServerRpc({
	id: "df45e0156a38bcb835bda4853bf7933ca17796830fbbed978bf5676ce7b33191",
	name: "updateCustomer",
	filename: "src/lib/cinema/api.ts"
}, (opts) => updateCustomer.__executeServer(opts));
var updateCustomer = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({
	id: number().int().positive(),
	person: personSchema
}), input)).handler(updateCustomer_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		assertHouse(data.code);
		await sql.query(`update customers set full_name = $1, phone = $2, email = $3 where id = $4`, [
			data.person.fullName,
			data.person.phone,
			data.person.email,
			data.id
		]);
		return bundle(sql);
	});
});
var deleteCustomer_createServerFn_handler = createServerRpc({
	id: "091f7a39564dec35e4012b0512979f9b49c7c486ca79b8aa25984bdab6e5d397",
	name: "deleteCustomer",
	filename: "src/lib/cinema/api.ts"
}, (opts) => deleteCustomer.__executeServer(opts));
var deleteCustomer = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ id: number().int().positive() }), input)).handler(deleteCustomer_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		assertHouse(data.code);
		if (num((await sql.query(`select count(*) as n from bookings where customer_id = $1`, [data.id]))[0]?.n) > 0) throw new CinemaError("This guest still has bookings. Cancel them before removing the record.");
		await sql.query(`delete from customers where id = $1`, [data.id]);
		return bundle(sql);
	});
});
var setBookingStatus_createServerFn_handler = createServerRpc({
	id: "2cc35c237ddf0fcae2516f8da3d65e67961c63fafda357e83ce07e27b89aeab9",
	name: "setBookingStatus",
	filename: "src/lib/cinema/api.ts"
}, (opts) => setBookingStatus.__executeServer(opts));
var setBookingStatus = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({
	id: number().int().positive(),
	status: _enum(["Cancelled", "Used"])
}), input)).handler(setBookingStatus_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		assertHouse(data.code);
		const rows = await sql.query(`select booking_status from bookings where id = $1`, [data.id]);
		if (!rows[0]) throw new CinemaError("That booking is not on file.");
		if (rows[0].booking_status !== "Confirmed") throw new CinemaError("Only a confirmed ticket can be marked used or cancelled.");
		if (data.status === "Cancelled") {
			await sql.query(`delete from booking_seats where booking_id = $1`, [data.id]);
			await sql.query(`update bookings set booking_status = 'Cancelled', payment_status = 'Refunded' where id = $1`, [data.id]);
			await sql.query(`update payments set payment_status = 'Refunded' where booking_id = $1`, [data.id]);
		} else await sql.query(`update bookings set booking_status = 'Used' where id = $1`, [data.id]);
		return bundle(sql);
	});
});
var verifyTicket_createServerFn_handler = createServerRpc({
	id: "5a1a726b85e11498dbd69a499be77a683eb231664e5191a1914991de4b6a5dd9",
	name: "verifyTicket",
	filename: "src/lib/cinema/api.ts"
}, (opts) => verifyTicket.__executeServer(opts));
var verifyTicket = createServerFn({ method: "POST" }).validator((input) => parse(houseSchema.extend({ ticketCode: string().trim().min(4).max(40) }), input)).handler(verifyTicket_createServerFn_handler, async ({ data }) => {
	return db(async (sql) => {
		assertHouse(data.code);
		return loadTicket(sql, data.ticketCode);
	});
});
//#endregion
export { createBooking_createServerFn_handler, deleteCustomer_createServerFn_handler, deleteMovie_createServerFn_handler, deleteShowtime_createServerFn_handler, getHome_createServerFn_handler, getMovie_createServerFn_handler, getShowtime_createServerFn_handler, getTicket_createServerFn_handler, saveMovie_createServerFn_handler, saveShowtime_createServerFn_handler, setBookingStatus_createServerFn_handler, staffDesk_createServerFn_handler, updateCustomer_createServerFn_handler, verifyTicket_createServerFn_handler };
