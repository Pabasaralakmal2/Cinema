import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/cinema/shell";
import { Field, GoldButton, TextInput } from "@/components/cinema/ui";

export const Route = createFileRoute("/tickets")({
  component: TicketsPage,
});

function TicketsPage() {
  const navigate = useNavigate();
  const [code, setCode] = useState("");
  return (
    <Shell>
      <section className="mx-auto max-w-xl px-4 py-16 sm:px-6">
        <p className="text-xs tracking-widest text-gold">TICKETS</p>
        <h1 className="mt-2 font-display text-5xl">Find a booking</h1>
        <p className="mt-3 text-muted">Enter the code printed on the ticket. It looks like NEX-20261008-100001.</p>
        <form
          className="mt-8 grid gap-4"
          onSubmit={(event) => {
            event.preventDefault();
            const next = code.trim();
            if (next) void navigate({ to: "/ticket/$code", params: { code: next } });
          }}
        >
          <Field label="Booking code">
            <TextInput value={code} onChange={(event) => setCode(event.target.value)} autoCapitalize="characters" />
          </Field>
          <GoldButton type="submit" className="w-fit">Open ticket</GoldButton>
        </form>
      </section>
    </Shell>
  );
}
