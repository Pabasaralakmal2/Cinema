import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as formatDuration, c as priceFor, i as formatDay, o as formatLkr, r as formatClock, t as GENRES } from "./rules-COHaUayQ.mjs";
import { n as Shell } from "./shell-C7TEGcdy.mjs";
import { c as deleteMovie, d as saveShowtime, f as setBookingStatus, h as verifyTicket, l as deleteShowtime, m as updateCustomer, p as staffDesk, s as deleteCustomer, u as saveMovie } from "./router-BYYkZVLE.mjs";
import { a as Note, i as GoldButton, n as Field, o as SelectInput, r as GhostButton, s as TextInput, t as Area } from "./ui-BSmzlgpM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/staff-T7Pv3mvG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var sections = [
	"Dashboard",
	"Movies",
	"Showtimes",
	"Halls",
	"Bookings",
	"Customers",
	"Verify"
];
var emptyMovie = () => ({
	title: "",
	genre: "Drama",
	durationMin: 120,
	description: "",
	posterUrl: "/films/eclipse-meridian.jpg",
	trailerUrl: "https://www.youtube.com/watch?v=R6MlUcmOul8",
	format: "2D",
	releaseDate: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
	status: "Now Showing"
});
function StaffPage() {
	const [code, setCode] = (0, import_react.useState)("");
	const [house, setHouse] = (0, import_react.useState)("");
	const [desk, setDesk] = (0, import_react.useState)(null);
	const [section, setSection] = (0, import_react.useState)("Dashboard");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const saved = sessionStorage.getItem("nexora-house");
		if (saved) {
			setHouse(saved);
			setCode(saved);
		}
	}, []);
	async function run(fn) {
		setBusy(true);
		setError("");
		try {
			return await fn();
		} catch (err) {
			setError(err instanceof Error ? err.message : "The desk could not complete that.");
			return null;
		} finally {
			setBusy(false);
		}
	}
	async function enter(nextCode) {
		const bundle = await run(() => staffDesk({ data: { code: nextCode } }));
		if (!bundle) return;
		sessionStorage.setItem("nexora-house", nextCode);
		setHouse(nextCode);
		setDesk(bundle);
	}
	function apply(bundle) {
		if (bundle) setDesk(bundle);
	}
	if (!desk) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-md px-4 py-20 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-gold",
				children: "STAFF"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl",
				children: "House desk"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "The demonstration house code is NEXORA."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 grid gap-4",
				onSubmit: (event) => {
					event.preventDefault();
					enter(code);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "House code",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							type: "password",
							value: code,
							onChange: (event) => setCode(event.target.value),
							autoComplete: "current-password"
						})
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: error }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
						type: "submit",
						disabled: busy,
						children: busy ? "Checking…" : "Enter"
					})
				]
			})
		]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:px-6 lg:grid-cols-[12rem_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "flex flex-wrap gap-2 lg:flex-col",
			children: [sections.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					setSection(item);
					setError("");
				},
				className: `min-h-11 rounded-full px-4 text-left ${section === item ? "bg-gold text-bg" : "border border-line text-cream"}`,
				children: item
			}, item)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				onClick: () => {
					sessionStorage.removeItem("nexora-house");
					setDesk(null);
					setHouse("");
				},
				children: "Leave"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: error }) : null,
			section === "Dashboard" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, { desk }) : null,
			section === "Movies" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Movies, {
				desk,
				house,
				busy,
				onDone: apply,
				run
			}) : null,
			section === "Showtimes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Showtimes, {
				desk,
				house,
				busy,
				onDone: apply,
				run
			}) : null,
			section === "Halls" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Halls, { desk }) : null,
			section === "Bookings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookings, {
				desk,
				house,
				busy,
				onDone: apply,
				run
			}) : null,
			section === "Customers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Customers, {
				desk,
				house,
				busy,
				onDone: apply,
				run
			}) : null,
			section === "Verify" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Verify, { house }) : null
		] })]
	}) });
}
function Dashboard({ desk }) {
	const cards = [
		["Films", desk.stats.movies],
		["Now showing", desk.stats.now_showing],
		["Coming soon", desk.stats.coming_soon],
		["Bookings", desk.stats.bookings],
		["Today’s shows", desk.stats.today],
		["Guests", desk.stats.customers]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-5xl",
		children: "Tonight’s board"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-6 grid grid-cols-2 gap-3 md:grid-cols-3",
		children: cards.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-2xl border border-line bg-surface p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl tabular-nums",
				children: value
			})]
		}, label))
	})] });
}
function Movies({ desk, house, busy, onDone, run }) {
	const [draft, setDraft] = (0, import_react.useState)(emptyMovie());
	const [query, setQuery] = (0, import_react.useState)("");
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const films = desk.movies.filter((movie) => movie.title.toLowerCase().includes(query.trim().toLowerCase()) || movie.genre.toLowerCase().includes(query.trim().toLowerCase()));
	function edit(movie) {
		setDraft({
			id: movie.id,
			title: movie.title,
			genre: movie.genre,
			durationMin: movie.duration_min,
			description: movie.description,
			posterUrl: movie.poster_url,
			trailerUrl: movie.trailer_url,
			format: movie.format,
			releaseDate: movie.release_date,
			status: movie.status
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl",
			children: draft.id ? "Update film" : "Add a film"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-5 grid gap-3",
			onSubmit: (event) => {
				event.preventDefault();
				run(() => saveMovie({ data: {
					code: house,
					movie: draft
				} })).then(onDone);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Title",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								value: draft.title,
								onChange: (event) => setDraft({
									...draft,
									title: event.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
							label: "Genre",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								list: "genres",
								value: draft.genre,
								onChange: (event) => setDraft({
									...draft,
									genre: event.target.value
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "genres",
								children: GENRES.map((genre) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: genre }, genre))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Runtime in minutes",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								type: "number",
								value: draft.durationMin,
								onChange: (event) => setDraft({
									...draft,
									durationMin: Number(event.target.value)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Format",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
								value: draft.format,
								onChange: (event) => setDraft({
									...draft,
									format: event.target.value
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "2D" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "3D" })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Release date",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								type: "date",
								value: draft.releaseDate,
								onChange: (event) => setDraft({
									...draft,
									releaseDate: event.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Status",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
								value: draft.status,
								onChange: (event) => setDraft({
									...draft,
									status: event.target.value
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Now Showing" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Coming Soon" })]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Poster address",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.posterUrl,
						onChange: (event) => setDraft({
							...draft,
							posterUrl: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Trailer address",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.trailerUrl,
						onChange: (event) => setDraft({
							...draft,
							trailerUrl: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Description",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						value: draft.description,
						onChange: (event) => setDraft({
							...draft,
							description: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Shows as ",
						formatDuration(Number(draft.durationMin) || 0),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
						type: "submit",
						disabled: busy,
						children: draft.id ? "Save changes" : "Add film"
					}), draft.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						type: "button",
						onClick: () => setDraft(emptyMovie()),
						children: "Clear"
					}) : null]
				})
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
			value: query,
			onChange: (event) => setQuery(event.target.value),
			placeholder: "Search films",
			"aria-label": "Search films"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-3",
			children: films.map((movie) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl",
						children: movie.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							movie.genre,
							" · ",
							formatDuration(movie.duration_min),
							" · ",
							movie.format,
							" · ",
							movie.status
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							type: "button",
							onClick: () => edit(movie),
							children: "Edit"
						}), confirmId === movie.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
							type: "button",
							disabled: busy,
							onClick: () => void run(() => deleteMovie({ data: {
								code: house,
								id: movie.id
							} })).then((bundle) => {
								setConfirmId(null);
								onDone(bundle);
							}),
							children: "Confirm delete"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							type: "button",
							onClick: () => setConfirmId(movie.id),
							children: "Delete"
						})]
					})]
				})
			}, movie.id))
		})] })]
	});
}
function Showtimes({ desk, house, busy, onDone, run }) {
	const showing = desk.movies.filter((movie) => movie.status === "Now Showing");
	const [movieId, setMovieId] = (0, import_react.useState)(showing[0]?.id ?? 0);
	const [hallId, setHallId] = (0, import_react.useState)("C1");
	const [showDate, setShowDate] = (0, import_react.useState)(desk.showtimes[0]?.show_date ?? "");
	const [startTime, setStartTime] = (0, import_react.useState)("18:00");
	const [editing, setEditing] = (0, import_react.useState)(void 0);
	const movie = desk.movies.find((item) => item.id === Number(movieId));
	const price = movie ? priceFor(hallId, movie.format) : null;
	const halls = desk.halls.filter((hall) => movie?.format !== "3D" || hall.supports_3d);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl",
			children: editing ? "Update screening" : "Add a screening"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-5 grid gap-3 sm:grid-cols-2",
			onSubmit: (event) => {
				event.preventDefault();
				run(() => saveShowtime({ data: {
					code: house,
					show: {
						id: editing,
						movieId: Number(movieId),
						hallId,
						showDate,
						startTime
					}
				} })).then((bundle) => {
					if (bundle) {
						setEditing(void 0);
						onDone(bundle);
					}
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Film",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
						value: movieId,
						onChange: (event) => setMovieId(Number(event.target.value)),
						children: showing.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: item.id,
							children: [
								item.title,
								" · ",
								item.format
							]
						}, item.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Hall",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
						value: hallId,
						onChange: (event) => setHallId(event.target.value),
						children: halls.map((hall) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: hall.id,
							children: [
								hall.id,
								" · ",
								hall.name
							]
						}, hall.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "date",
						value: showDate,
						onChange: (event) => setShowDate(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Start",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "time",
						value: startTime,
						onChange: (event) => setStartTime(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "sm:col-span-2 text-sm text-gold",
					children: price == null ? "C3 cannot take a 3D film." : `Price ${formatLkr(price)} · set by the house, not by the form.`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3 sm:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
						type: "submit",
						disabled: busy || price == null,
						children: editing ? "Save screening" : "Add screening"
					}), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						type: "button",
						onClick: () => setEditing(void 0),
						children: "Clear"
					}) : null]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 grid gap-3",
			children: desk.showtimes.map((show) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: show.movie_title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						formatDay(show.show_date),
						" · ",
						formatClock(show.start_time),
						" · ",
						show.hall_id,
						" · ",
						show.format,
						" · ",
						formatLkr(show.ticket_price)
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						type: "button",
						onClick: () => {
							setEditing(show.id);
							setMovieId(show.movie_id);
							setHallId(show.hall_id);
							setShowDate(show.show_date);
							setStartTime(show.start_time);
						},
						children: "Edit"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						type: "button",
						disabled: busy,
						onClick: () => void run(() => deleteShowtime({ data: {
							code: house,
							id: show.id
						} })).then(onDone),
						children: "Delete"
					})]
				})]
			}, show.id))
		})
	] });
}
function Halls({ desk }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl",
			children: "Halls"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted",
			children: "Prices and 3D rights are house rules. C3 never takes a 3D print."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-3",
			children: desk.halls.map((hall) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-3xl",
						children: [
							hall.id,
							" · ",
							hall.name
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							hall.projection,
							" · ",
							hall.sound,
							" · ",
							hall.capacity,
							" seats"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2",
						children: [
							"2D ",
							formatLkr(hall.price_2d),
							" · ",
							hall.supports_3d && hall.price_3d != null ? `3D ${formatLkr(hall.price_3d)}` : "3D not available"
						]
					})
				]
			}, hall.id))
		})
	] });
}
function Bookings({ desk, house, busy, onDone, run }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		if (!q) return desk.bookings;
		return desk.bookings.filter((row) => `${row.ticket_code} ${row.full_name} ${row.movie_title} ${row.show_date} ${row.hall_id}`.toLowerCase().includes(q));
	}, [desk.bookings, query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl",
			children: "Bookings"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
			className: "mt-4",
			value: query,
			onChange: (event) => setQuery(event.target.value),
			placeholder: "Search code, guest, film, or date",
			"aria-label": "Search bookings"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-3",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-gold",
						children: row.ticket_code
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl",
						children: row.movie_title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							row.full_name,
							" · ",
							row.phone,
							" · ",
							row.email
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							formatDay(row.show_date),
							" · ",
							formatClock(row.start_time),
							" · ",
							row.hall_id,
							" · ",
							row.format,
							" · ",
							row.seat_list
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "tabular-nums",
						children: [
							formatLkr(row.total_amount),
							" · ",
							row.payment_status,
							" · ",
							row.booking_status
						]
					}),
					row.booking_status === "Confirmed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							type: "button",
							disabled: busy,
							onClick: () => void run(() => setBookingStatus({ data: {
								code: house,
								id: row.id,
								status: "Used"
							} })).then(onDone),
							children: "Mark used"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							type: "button",
							disabled: busy,
							onClick: () => void run(() => setBookingStatus({ data: {
								code: house,
								id: row.id,
								status: "Cancelled"
							} })).then(onDone),
							children: "Cancel and free seats"
						})]
					}) : null
				]
			}, row.id))
		})
	] });
}
function Customers({ desk, house, busy, onDone, run }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const [edit, setEdit] = (0, import_react.useState)(null);
	const rows = desk.customers.filter((row) => `${row.full_name} ${row.email} ${row.phone}`.toLowerCase().includes(query.trim().toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl",
			children: "Guests"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
			className: "mt-4",
			value: query,
			onChange: (event) => setQuery(event.target.value),
			placeholder: "Search guests",
			"aria-label": "Search guests"
		}),
		edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 grid gap-3 rounded-2xl border border-line bg-surface p-4",
			onSubmit: (event) => {
				event.preventDefault();
				run(() => updateCustomer({ data: {
					code: house,
					id: edit.id,
					person: {
						fullName: edit.full_name,
						phone: edit.phone,
						email: edit.email
					}
				} })).then((bundle) => {
					if (bundle) {
						setEdit(null);
						onDone(bundle);
					}
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: edit.full_name,
						onChange: (event) => setEdit({
							...edit,
							full_name: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Phone",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: edit.phone,
						onChange: (event) => setEdit({
							...edit,
							phone: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: edit.email,
						onChange: (event) => setEdit({
							...edit,
							email: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
						type: "submit",
						disabled: busy,
						children: "Save guest"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						type: "button",
						onClick: () => setEdit(null),
						children: "Close"
					})]
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-3",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: row.full_name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						row.phone,
						" · ",
						row.email,
						" · ",
						row.bookings,
						" bookings"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						type: "button",
						onClick: () => setEdit(row),
						children: "Edit"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						type: "button",
						disabled: busy || row.bookings > 0,
						onClick: () => void run(() => deleteCustomer({ data: {
							code: house,
							id: row.id
						} })).then(onDone),
						children: "Delete"
					})]
				})]
			}, row.id))
		})
	] });
}
function Verify({ house }) {
	const [ticketCode, setTicketCode] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [ok, setOk] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl",
			children: "Check a ticket"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-5 grid max-w-md gap-3",
			onSubmit: (event) => {
				event.preventDefault();
				verifyTicket({ data: {
					code: house,
					ticketCode
				} }).then((ticket) => {
					if (!ticket) {
						setOk(false);
						setMessage("No ticket matches that code.");
						return;
					}
					setOk(ticket.verdict === "valid");
					setMessage(ticket.verdict === "valid" ? `Valid ticket. ${ticket.title}, ${ticket.seats}, ${ticket.hall_id}.` : `Invalid or used. Status: ${ticket.booking_status}.`);
				}).catch((err) => {
					setOk(false);
					setMessage(err instanceof Error ? err.message : "Could not check that ticket.");
				});
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Booking code",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					value: ticketCode,
					onChange: (event) => setTicketCode(event.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
				type: "submit",
				className: "w-fit",
				children: "Check"
			})]
		}),
		ok != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `mt-4 ${ok ? "text-gold" : "text-alert"}`,
			children: message
		}) : null
	] });
}
//#endregion
export { StaffPage as component };
