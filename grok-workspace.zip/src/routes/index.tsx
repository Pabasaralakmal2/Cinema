import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { MovieCard } from "@/components/cinema/movie-card";
import { Pending, Shell } from "@/components/cinema/shell";
import { getHome } from "@/lib/cinema/api";
import { formatLkr } from "@/lib/cinema/rules";
import type { Movie } from "@/lib/cinema/types";

export const Route = createFileRoute("/")({
  loader: () => getHome(),
  pendingComponent: Pending,
  component: Home,
});

function matches(movie: Movie, query: string, genre: string, format: string) {
  const q = query.trim().toLowerCase();
  if (q && !`${movie.title} ${movie.genre}`.toLowerCase().includes(q)) return false;
  if (genre !== "All" && movie.genre !== genre) return false;
  if (format !== "All" && movie.format !== format) return false;
  return true;
}

function Home() {
  const { movies, halls } = Route.useLoaderData();
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("All");
  const [format, setFormat] = useState("All");
  const genres = useMemo(() => ["All", ...new Set(movies.map((movie) => movie.genre))], [movies]);
  const showing = movies.filter((movie) => movie.status === "Now Showing" && matches(movie, query, genre, format));
  const soon = movies.filter((movie) => movie.status === "Coming Soon" && matches(movie, query, genre, format));

  return (
    <Shell>
      <section className="relative min-h-[78vh] overflow-hidden">
        <img src="/films/hero.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" fetchPriority="high" />
        <div className="absolute inset-0 bg-bg/75" />
        <div className="relative mx-auto flex min-h-[78vh] max-w-6xl flex-col justify-end px-4 py-16 sm:px-6">
          <p className="text-xs tracking-widest text-gold">NEXORA DOLBY CINEMA</p>
          <h1 className="mt-3 max-w-3xl font-display text-6xl leading-none text-cream sm:text-7xl">
            Where stories become worlds.
          </h1>
          <p className="mt-5 max-w-xl text-lg text-cream">
            Three houses under one roof. Dolby Atmos and 8K laser in C1. A seat is held for one screening, never for the hall.
          </p>
          <a href="#now" className="mt-8 inline-flex min-h-11 w-fit items-center rounded-full bg-gold px-5 font-medium text-bg">
            See what is on
          </a>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="grid gap-3 sm:grid-cols-3">
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search the programme"
            aria-label="Search the programme"
            className="min-h-11 rounded-lg border border-line bg-surface px-3 text-cream placeholder:text-muted"
          />
          <select
            value={genre}
            onChange={(event) => setGenre(event.target.value)}
            aria-label="Filter by genre"
            className="min-h-11 rounded-lg border border-line bg-surface px-3 text-cream"
          >
            {genres.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
          <select
            value={format}
            onChange={(event) => setFormat(event.target.value)}
            aria-label="Filter by format"
            className="min-h-11 rounded-lg border border-line bg-surface px-3 text-cream"
          >
            <option>All</option>
            <option>2D</option>
            <option>3D</option>
          </select>
        </div>
      </section>

      <section id="now" className="mx-auto max-w-6xl scroll-mt-24 px-4 sm:px-6">
        <h2 className="font-display text-5xl">Now showing</h2>
        {showing.length === 0 ? (
          <p className="mt-6 text-muted">Nothing on the board matches that.</p>
        ) : (
          <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-3">
            {showing.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        )}
      </section>

      <section id="soon" className="mx-auto mt-16 max-w-6xl scroll-mt-24 px-4 sm:px-6">
        <h2 className="font-display text-5xl">Coming soon</h2>
        <p className="mt-2 text-muted">These are not open for seats yet.</p>
        {soon.length === 0 ? (
          <p className="mt-6 text-muted">No coming titles match that search.</p>
        ) : (
          <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-3">
            {soon.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        )}
      </section>

      <section id="halls" className="mx-auto mt-20 max-w-6xl scroll-mt-24 px-4 sm:px-6">
        <h2 className="font-display text-5xl">The houses</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {halls.map((hall) => (
            <article key={hall.id} className="rounded-2xl border border-line bg-surface p-5">
              <p className="text-xs tracking-widest text-gold">{hall.id}</p>
              <h3 className="mt-2 font-display text-3xl">{hall.name}</h3>
              <p className="mt-1 text-sm text-muted">{hall.tagline}</p>
              <ul className="mt-4 space-y-1 text-sm">
                <li>{hall.projection}</li>
                <li>{hall.sound}</li>
                <li>{hall.capacity} seats · rows A to G</li>
                <li>2D {formatLkr(hall.price_2d)}</li>
                <li>{hall.price_3d == null ? "3D not available" : `3D ${formatLkr(hall.price_3d)}`}</li>
              </ul>
            </article>
          ))}
        </div>
      </section>
    </Shell>
  );
}
