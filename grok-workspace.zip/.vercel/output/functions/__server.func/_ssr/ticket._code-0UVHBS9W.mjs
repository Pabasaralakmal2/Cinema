import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as formatDay, o as formatLkr, r as formatClock } from "./rules-COHaUayQ.mjs";
import { n as Shell } from "./shell-C7TEGcdy.mjs";
import { n as Route } from "./router-BYYkZVLE.mjs";
import { i as GoldButton } from "./ui-BSmzlgpM.mjs";
import { t as require_lib } from "../_libs/qrcode.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ticket._code-0UVHBS9W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
function payload(ticket) {
	return [
		"NEXORA DOLBY CINEMA",
		ticket.ticket_code,
		ticket.title,
		`${ticket.show_date} ${ticket.start_time}`,
		`${ticket.hall_id} ${ticket.format}`,
		`Seats: ${ticket.seats}`,
		ticket.full_name
	].join("\n");
}
function TicketPage() {
	const ticket = Route.useLoaderData();
	const [qr, setQr] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!ticket) return;
		let live = true;
		import_lib.toDataURL(payload(ticket), {
			margin: 1,
			width: 320,
			color: {
				dark: "#14110e",
				light: "#f3ecdf"
			}
		}).then((url) => {
			if (live) setQr(url);
		});
		return () => {
			live = false;
		};
	}, [ticket]);
	if (!ticket) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-6 py-24 text-muted",
		children: "No ticket matches that code."
	}) });
	const pass = ticket;
	async function save() {
		if (!qr) return;
		await document.fonts.ready;
		const canvas = document.createElement("canvas");
		canvas.width = 1200;
		canvas.height = 560;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.fillStyle = "#14110e";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		ctx.strokeStyle = "#c6a36a";
		ctx.strokeRect(24, 24, canvas.width - 48, canvas.height - 48);
		ctx.fillStyle = "#c6a36a";
		ctx.font = "500 22px Outfit, sans-serif";
		ctx.fillText("NEXORA DOLBY CINEMA", 64, 88);
		ctx.fillStyle = "#f3ecdf";
		ctx.font = "600 64px Cormorant Garamond, serif";
		ctx.fillText(pass.title, 64, 170);
		ctx.font = "400 28px Outfit, sans-serif";
		[
			`${formatDay(pass.show_date)}  ·  ${formatClock(pass.start_time)}`,
			`${pass.hall_id}  ${pass.hall_name}  ·  ${pass.format}`,
			`Seats  ${pass.seats}`,
			pass.full_name,
			formatLkr(pass.total_amount),
			pass.ticket_code
		].forEach((line, index) => ctx.fillText(line, 64, 230 + index * 42));
		const img = new Image();
		img.onload = () => {
			ctx.drawImage(img, 900, 160, 220, 220);
			const link = document.createElement("a");
			link.href = canvas.toDataURL("image/png");
			link.download = `${pass.ticket_code}.png`;
			link.click();
		};
		img.src = qr;
	}
	const valid = pass.verdict === "valid";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 py-10 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-gold",
				children: valid ? "BOOKING CONFIRMED" : ticket.booking_status.toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl",
				children: "Your ticket"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mt-8 grid gap-6 rounded-2xl border border-gold bg-surface p-6 sm:grid-cols-[1fr_180px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl",
						children: ticket.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-2 gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: formatDay(ticket.show_date) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Time"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: formatClock(ticket.start_time)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Hall"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [
								ticket.hall_id,
								" · ",
								ticket.hall_name
							] })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Format"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: ticket.format })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Seats"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: ticket.seats })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Guest"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: ticket.full_name })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Total"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: formatLkr(ticket.total_amount)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Booking"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: ticket.ticket_code })] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-muted",
						children: [
							ticket.projection,
							" · ",
							ticket.sound
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col items-center justify-center",
					children: qr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: qr,
						alt: `QR code for ${ticket.ticket_code}`,
						className: "w-40 rounded-lg bg-cream p-2"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Drawing the code…"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldButton, {
				className: "mt-6",
				onClick: () => void save(),
				disabled: !qr,
				children: "Save ticket"
			})
		]
	}) });
}
//#endregion
export { TicketPage as component };
